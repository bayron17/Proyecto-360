
from django.contrib import admin
from django.urls import path, include
from appTaller import views as taller_views

urlpatterns = [
    path("admin/", admin.site.urls),

    # Login, logout y gestión de usuarios
    path("", include("cuentas.urls")),

    # Gestión de talleres
    path("talleres/", include("talleres.urls")),

    # Acceso a las órdenes de trabajo
    path(
        "ordenes/",
        taller_views.base,
        name="lista_ordenes"
    ),

    # Módulos principales de Taller360
    path("", include("appTaller.urls")),
]
