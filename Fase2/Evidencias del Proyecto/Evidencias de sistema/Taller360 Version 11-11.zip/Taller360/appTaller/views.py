from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Q, Count
from .forms import  EditarOrdenTrabajoForm, OrdenTrabajoForm, ClienteForm, RecepcionVehiculoForm, VehiculoForm, DetallePresupuestoForm
from .models import DetallePresupuesto, OrdenTrabajo, Cliente, RecepcionVehiculo, Vehiculo, Presupuesto
from .services import agregar_detalle_presupuesto, aprobar_presupuesto, crear_version_presupuesto, editar_detalle_presupuesto, eliminar_detalle_presupuesto, enviar_presupuesto, rechazar_presupuesto
from django.contrib import messages
import re
import requests
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_POST
from django.utils import timezone
from django.core.exceptions import PermissionDenied
from cuentas.models import Usuario
from talleres.models import Taller
from cuentas.permisos import requiere_roles, es_superadmin


ROLES_OPERACION = (Usuario.Rol.SUPERADMIN, Usuario.Rol.ADMIN_TALLER, Usuario.Rol.RECEPCION, Usuario.Rol.MECANICO)
ROLES_GESTION = (Usuario.Rol.SUPERADMIN, Usuario.Rol.ADMIN_TALLER, Usuario.Rol.RECEPCION)


def _scope(request, queryset):
    """Limita cualquier consulta operativa al taller del usuario."""
    if es_superadmin(request.user):
        return queryset
    if not request.user.taller_id:
        raise PermissionDenied("Tu cuenta no tiene un taller asignado.")
    queryset = queryset.filter(taller_id=request.user.taller_id)
    if queryset.model is OrdenTrabajo and request.user.rol == Usuario.Rol.MECANICO:
        queryset = queryset.filter(mecanico_asignado=request.user)
    return queryset


def _get_obj(request, model_or_queryset, **filters):
    queryset = model_or_queryset.objects.all() if hasattr(model_or_queryset, "objects") else model_or_queryset
    return get_object_or_404(_scope(request, queryset), **filters)


def _taller_para_nuevo_registro(request, cliente=None):
    if cliente is not None and cliente.taller_id:
        return cliente.taller_id
    if request.user.rol == Usuario.Rol.SUPERADMIN:
        return Taller.objects.filter(activo=True).order_by("id").values_list("id", flat=True).first()
    return request.user.taller_id


def _get_detalle(request, **filters):
    qs = DetallePresupuesto.objects.select_related("presupuesto", "presupuesto__recepcion", "presupuesto__orden")
    if not es_superadmin(request.user):
        if not request.user.taller_id:
            raise PermissionDenied("Tu cuenta no tiene un taller asignado.")
        qs = qs.filter(presupuesto__taller_id=request.user.taller_id)
    return get_object_or_404(qs, **filters)


@requiere_roles(*ROLES_OPERACION)
def base(request):


    # ordenes_activas = OrdenTrabajo.objects.exclude(
    #     estado__in=["ENTREGADO", "CANCELADO"]
    # ).count()

    # ordenes_listas = OrdenTrabajo.objects.filter(
    #     estado="LISTO"
    # ).count()

    # ordenes_reparacion = OrdenTrabajo.objects.filter(
    #     estado="EN_REPARACION"
    # ).count()

    # ordenes_repuestos = OrdenTrabajo.objects.filter(
    #     estado="ESPERANDO_REPUESTO"
    # ).count()

    # -------------------------
    # LISTADO DE ÓRDENES
    # -------------------------

    ordenes = _scope(request, OrdenTrabajo.objects.select_related(
        "cliente",
        "vehiculo"
    )).order_by("-fecha_ingreso")

    # -------------------------
    # BUSCADOR POR PATENTE
    # -------------------------

    patente = request.GET.get("patente", "").strip()

    if patente:
        ordenes = ordenes.filter(
            vehiculo__patente__icontains=patente
        )

    # -------------------------
    # FILTRO POR ESTADO
    # -------------------------

    estado = request.GET.get("estado", "").strip()

    estados_validos = [
        "EN_REPARACION",
        "ESPERANDO_REPUESTO",
        "LISTO",
    ]

    if estado in estados_validos:
        ordenes = ordenes.filter(estado=estado)

    # -------------------------
    # DATOS PARA EL HTML
    # -------------------------

    context = {
        # "ordenes_activas": ordenes_activas,
        # "ordenes_listas": ordenes_listas,
        # "ordenes_reparacion": ordenes_reparacion,
        # "ordenes_repuestos": ordenes_repuestos,
        "ordenes": ordenes,
        "patente_busqueda": patente,
        "estado_filtro": estado,
    }

    return render(request, "inicio.html", context)

@requiere_roles(*ROLES_GESTION)
def nueva_orden(request):
    messages.info(
        request,
        "Las órdenes de trabajo ahora se generan al aprobar el presupuesto de una recepción. "
        "Registra primero la recepción del vehículo."
    )
    return redirect("nueva_recepcion")


@requiere_roles(*ROLES_GESTION)
def editar_orden(request, id):

    orden = _get_obj(request, OrdenTrabajo, id=id)

    if request.method == "POST":

        form = EditarOrdenTrabajoForm(request.POST, instance=orden)
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())
        form.fields["vehiculo"].queryset = _scope(request, Vehiculo.objects.all())

        if form.is_valid():
            form.save()

            messages.success(request,"Los datos de la orden se actualizaron correctamente.")

            return redirect("detalle_orden", id=orden.id)
        else:
            messages.error(request,"Hubo un error al actualizar la orden. Por favor, verifica los datos ingresados.")

            form = EditarOrdenTrabajoForm(request.POST, instance=orden)
    else:
        form = EditarOrdenTrabajoForm(instance=orden)
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())
        form.fields["vehiculo"].queryset = _scope(request, Vehiculo.objects.all())
        form.fields["mecanico_asignado"].queryset = Usuario.objects.filter(rol=Usuario.Rol.MECANICO) if es_superadmin(request.user) else Usuario.objects.filter(taller_id=request.user.taller_id, rol=Usuario.Rol.MECANICO)

    return render(request, "ordenes/editar_orden.html", {
        "form": form,
        "orden": orden
    })


@requiere_roles(*ROLES_GESTION)
def eliminar_orden(request, id):

    orden = _get_obj(request, OrdenTrabajo, id=id)

    estados_bloqueados = [
        "ENTREGADO",
        "CANCELADO",
        "ESPERANDO_REPUESTO",
        "RECEPCION",
        "CONTROL",
        "EN_REPARACION",
        "ESPERANDO_APROBACION",
        "PRESUPUESTO",
        "DIAGNOSTICO",
    ]

    puede_eliminar = orden.estado not in estados_bloqueados

    if request.method == "POST":

        if not puede_eliminar:
            messages.error(
                request,
                "No puedes eliminar esta orden debido a su estado actual."
            )

            return redirect("/#containerOrdenes")

        orden.delete()

        messages.success(
            request,
            "La orden se eliminó correctamente."
        )

        return redirect("/#containerOrdenes")

    return render(
        request,
        "ordenes/eliminar_orden.html",
        {
            "orden": orden,
            "puede_eliminar": puede_eliminar,
        }
    )


@requiere_roles(*ROLES_OPERACION)
def detalle_orden(request, id):
    orden = _get_obj(request, OrdenTrabajo.objects.select_related("cliente", "vehiculo"),
        id=id
    )

    return render(request, "ordenes/detalle_orden.html", {
        "orden": orden
    })



@requiere_roles(*ROLES_OPERACION)
def lista_clientes(request):

    busqueda = request.GET.get("q", "").strip()

    clientes = _scope(request, Cliente.objects.annotate(
        total_vehiculos=Count("vehiculos")
    )).order_by("nombre")

    if busqueda:
        clientes = clientes.filter(
            Q(nombre__icontains=busqueda) |
            Q(rut__icontains=busqueda)
        )

    context = {
        "clientes": clientes,
        "busqueda": busqueda,
    }

    return render(
        request,
        "clientes/lista_clientes.html",
        context
    )


@requiere_roles(*ROLES_GESTION)
def nuevo_cliente(request):

    if request.method == "POST":
        form = ClienteForm(request.POST)

        if form.is_valid():
            cliente = form.save(commit=False)
            cliente.taller_id = _taller_para_nuevo_registro(request)
            cliente.save()
            messages.success( request, "El cliente se registró correctamente.")
            return redirect("lista_clientes")

    else:
        form = ClienteForm()

    return render(
        request,
        "clientes/nuevo_cliente.html",
        {"form": form}
    )

@requiere_roles(*ROLES_GESTION)
def editar_cliente(request, id):

    cliente = _get_obj(request, Cliente, id=id)

    if request.method == "POST":
        form = ClienteForm(request.POST, instance=cliente)

        if form.is_valid():
            cliente_editado = form.save(commit=False)
            if not es_superadmin(request.user):
                cliente_editado.taller_id = request.user.taller_id
            cliente_editado.save()

            messages.success(
                request,
                "Los datos del cliente se actualizaron correctamente."
            )

            return redirect("detalle_cliente", id=cliente.id)

    else:
        form = ClienteForm(instance=cliente)

    return render(
        request,
        "clientes/editar_cliente.html",
        {
            "form": form,
            "cliente": cliente,
        }
    )

@requiere_roles(*ROLES_GESTION)
def eliminar_cliente(request, id):

    cliente = _get_obj(request, Cliente, id=id)

    tiene_vehiculos = cliente.vehiculos.exists()
    tiene_ordenes = cliente.ordenes.exists()

    puede_eliminar = not (tiene_vehiculos or tiene_ordenes)

    if request.method == "POST":

        if not puede_eliminar:
            messages.error(
                request,
                "No puedes eliminar este cliente porque tiene "
                "vehículos u órdenes de trabajo asociadas."
            )

            return redirect("detalle_cliente", id=cliente.id)

        cliente.delete()

        messages.success(
            request,
            "El cliente se eliminó correctamente."
        )

        return redirect("lista_clientes")

    return render(
        request,
        "clientes/eliminar_cliente.html",
        {
            "cliente": cliente,
            "puede_eliminar": puede_eliminar,
            "tiene_vehiculos": tiene_vehiculos,
            "tiene_ordenes": tiene_ordenes,
        }
    )

@requiere_roles(*ROLES_OPERACION)
def detalle_cliente(request, id):

    cliente = _get_obj(request, Cliente.objects.prefetch_related("vehiculos"),
        id=id
    )

    return render(
        request,
        "clientes/detalle_cliente.html",
        {"cliente": cliente}
    )

@requiere_roles(*ROLES_OPERACION)
def lista_vehiculos(request):

    busqueda = request.GET.get("q", "").strip()

    vehiculos = _scope(request, Vehiculo.objects.select_related(
        "cliente"
    )).order_by("patente")

    if busqueda:
        vehiculos = vehiculos.filter(
            Q(patente__icontains=busqueda) |
            Q(marca__icontains=busqueda) |
            Q(modelo__icontains=busqueda) |
            Q(cliente__nombre__icontains=busqueda)
        )

    context = {
        "vehiculos": vehiculos,
        "busqueda": busqueda,
    }

    return render(
        request,
        "vehiculos/lista_vehiculos.html",
        context
    )


@requiere_roles(*ROLES_GESTION)
def nuevo_vehiculo(request):

    if request.method == "POST":
        form = VehiculoForm(request.POST)
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())

        if form.is_valid():
            vehiculo = form.save(commit=False)
            vehiculo.taller_id = _taller_para_nuevo_registro(request, vehiculo.cliente)
            vehiculo.save()
            return redirect("lista_vehiculos")

    else:
        form = VehiculoForm()
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())

    return render(
        request,
        "vehiculos/nuevo_vehiculo.html",
        {"form": form}
    )

@requiere_roles(*ROLES_GESTION)
def editar_vehiculo(request, patente):

    vehiculo = _get_obj(request, Vehiculo, patente=patente)

    if request.method == "POST":

        form = VehiculoForm(request.POST, instance=vehiculo)
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())

        if form.is_valid():

            vehiculo_editado = form.save(commit=False)
            if not es_superadmin(request.user):
                vehiculo_editado.taller_id = request.user.taller_id
            else:
                vehiculo_editado.taller_id = vehiculo_editado.cliente.taller_id
            vehiculo_editado.save()

            messages.success(
                request,
                "Los datos del vehículo se actualizaron correctamente."
            )

            return redirect("lista_vehiculos")

    else:
        form = VehiculoForm(instance=vehiculo)
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())

    
    return render(
        request,
        "vehiculos/editar_vehiculo.html",
        {
            "form": form,
            "vehiculo": vehiculo,
        }
    )

@requiere_roles(*ROLES_GESTION)
def eliminar_vehiculo(request, patente):

    vehiculo = _get_obj(request, Vehiculo, patente=patente)

    # Comprobar si tiene órdenes asociadas
    tiene_ordenes = vehiculo.ordenes.exists()

    # Solo se puede eliminar si NO tiene órdenes
    puede_eliminar = not tiene_ordenes

    if request.method == "POST":

        if not puede_eliminar:

            messages.error(
                request,
                "No puedes eliminar este vehículo porque tiene "
                "órdenes de trabajo asociadas."
            )

            return redirect("lista_vehiculos")

        vehiculo.delete()

        messages.success(
            request,
            "El vehículo se eliminó correctamente."
        )

        return redirect("lista_vehiculos")

    return render(
        request,
        "vehiculos/eliminar_vehiculo.html",
        {
            "vehiculo": vehiculo,
            "puede_eliminar": puede_eliminar,
            "tiene_ordenes": tiene_ordenes,
        }
    )

@requiere_roles(*ROLES_OPERACION)
def detalle_vehiculo(request, patente):
    vehiculo = _get_obj(request, Vehiculo.objects.select_related("cliente"),
        patente=patente
    )

    return render(
        request,
        "vehiculos/detalle_vehiculo.html",
        {"vehiculo": vehiculo}
    )


   
@requiere_roles(*ROLES_OPERACION)
def dashboard(request):
  hoy = timezone.now().date()

  # 1. Métricas para las tarjetas del panel principal
  ordenes_base = _scope(request, OrdenTrabajo.objects.all())
  ordenes_activas = ordenes_base.exclude(
      estado__in=["ENTREGADO", "CANCELADO"]
  ).count()

  ordenes_listas = ordenes_base.filter(estado="LISTO").count()

  ordenes_reparacion = ordenes_base.filter(
      estado="EN_REPARACION"
  ).count()

  ordenes_repuestos = ordenes_base.filter(
      estado="ESPERANDO_REPUESTO"
  ).count()

  # 2. Datos para el apartado de entregas
  ordenes_pendientes = (
      ordenes_base.exclude(estado__in=["ENTREGADO", "CANCELADO"])
      .filter(fecha_entrega__isnull=False)
      .order_by("fecha_entrega")
  )

  entregas_hoy = ordenes_pendientes.filter(fecha_entrega__date=hoy)

  # 3. Diccionario context unificado con todo
  context = {
      "ordenes_activas": ordenes_activas,
      "ordenes_listas": ordenes_listas,
      "ordenes_reparacion": ordenes_reparacion,
      "ordenes_repuestos": ordenes_repuestos,
      "ordenes_pendientes": ordenes_pendientes,
      "entregas_hoy": entregas_hoy,
  }

  return render(request, "dashboard.html", context)


# Si prefieres mantener la vista de entregas separada en otra página/URL:
@requiere_roles(*ROLES_OPERACION)
def entregas_view(request):
  hoy = timezone.now().date()

  ordenes_pendientes = (
      _scope(request, OrdenTrabajo.objects.all()).exclude(estado__in=["ENTREGADO", "CANCELADO"])
      .filter(fecha_entrega__isnull=False)
      .order_by("fecha_entrega")
  )

  entregas_hoy = ordenes_pendientes.filter(fecha_entrega__date=hoy)

  context = {
      "ordenes_pendientes": ordenes_pendientes,
      "entregas_hoy": entregas_hoy,
  }
  return render(request, "taller/entregas.html", context)


# api

@require_GET
@requiere_roles(*ROLES_GESTION)
def consultar_patente(request):

    patente = request.GET.get("patente", "").strip().upper()
    patente = re.sub(r"[\s.-]", "", patente)

    if not re.fullmatch(r"(?:[A-Z]{2}[0-9]{4}|[A-Z]{4}[0-9]{2}|[A-Z]{3}[0-9]{3})", patente):
        return JsonResponse({
            "error": "La patente ingresada no tiene un formato válido."
        }, status=400)

    if not settings.BOOSTR_API_KEY:
        return JsonResponse({
            "error": "La clave de Boostr no está configurada."
        }, status=500)

    try:
        respuesta = requests.get(
            f"https://api.boostr.cl/vehicle/{patente}.json",
            headers={
                "X-API-KEY": settings.BOOSTR_API_KEY
            },
            timeout=10
        )

        if respuesta.status_code != 200:
            return JsonResponse({
                "error": "No fue posible obtener los datos del vehículo.",
                "codigo": respuesta.status_code
            }, status=502)

        datos = respuesta.json()

        return JsonResponse(datos, safe=isinstance(datos, dict))

    except requests.Timeout:
        return JsonResponse({
            "error": "La API tardó demasiado en responder."
        }, status=504)

    except (requests.RequestException, ValueError):
        return JsonResponse({
            "error": "Ocurrió un error al consultar la API."
        }, status=502)



@requiere_roles(*ROLES_GESTION)
def presupuestos_recepcion(request, recepcion_id):

    recepcion = _get_obj(request, RecepcionVehiculo, pk=recepcion_id
    )

    presupuestos = (recepcion.presupuestos.prefetch_related("detalles").order_by("-version"))

    return render(
        request,
        "presupuestos.html",
        {
            "recepcion": recepcion,
            "presupuestos": presupuestos,
        }
    )



@requiere_roles(*ROLES_GESTION)
def agregar_detalle(request, presupuesto_id):
    presupuesto = _get_obj(request, Presupuesto, pk=presupuesto_id)

    if request.method == "POST":
        form = DetallePresupuestoForm(request.POST)

        if form.is_valid():
            try:
                agregar_detalle_presupuesto(
                    presupuesto.id,
                    form.cleaned_data
                )

                messages.success(
                    request,
                    "Detalle agregado correctamente."
                )

                # Presupuestos del nuevo flujo
                if presupuesto.recepcion_id:
                    return redirect(
                        "presupuestos_recepcion",
                        recepcion_id=presupuesto.recepcion_id
                    )

                # Presupuestos del flujo antiguo
                if presupuesto.orden_id:
                    return redirect(
                        "presupuestos_orden",
                        orden_id=presupuesto.orden_id
                    )

                messages.error(
                    request,
                    "El presupuesto no tiene una recepción ni una orden asociada."
                )

            except ValueError as error:
                messages.error(request, str(error))

        else:
            messages.error(
                request,
                "Revisa los datos ingresados."
            )
    else:
        form = DetallePresupuestoForm()

    return render(
        request,
        "agregar_detalle.html",
        {
            "form": form,
            "presupuesto": presupuesto
        }
    )


@requiere_roles(*ROLES_GESTION)
def editar_detalle(request, detalle_id):
    detalle = _get_detalle(request,
        pk=detalle_id
    )

    presupuesto = detalle.presupuesto

    if presupuesto.estado != "BORRADOR":
        messages.error(
            request,
            "No puedes editar detalles de un presupuesto que no está en borrador."
        )

        if presupuesto.recepcion_id:
            return redirect(
                "presupuestos_recepcion",
                recepcion_id=presupuesto.recepcion_id
            )

        return redirect(
            "presupuestos_orden",
            orden_id=presupuesto.orden_id
        )

    if request.method == "POST":
        form = DetallePresupuestoForm(
            request.POST,
            instance=detalle
        )

        if form.is_valid():
            try:
                editar_detalle_presupuesto(
                    detalle.id,
                    form.cleaned_data
                )

                messages.success(
                    request,
                    "Detalle actualizado correctamente."
                )

                if presupuesto.recepcion_id:
                    return redirect(
                        "presupuestos_recepcion",
                        recepcion_id=presupuesto.recepcion_id
                    )

                return redirect(
                    "presupuestos_orden",
                    orden_id=presupuesto.orden_id
                )

            except ValueError as error:
                messages.error(request, str(error))

    else:
        form = DetallePresupuestoForm(instance=detalle)

    return render(
        request,
        "editar_detalle.html",
        {
            "form": form,
            "detalle": detalle,
            "presupuesto": presupuesto
        }
    )


@requiere_roles(*ROLES_GESTION)
def eliminar_detalle(request, detalle_id):

    detalle = _get_detalle(request,
        pk=detalle_id
    )

    presupuesto = detalle.presupuesto

    if request.method == "POST":
        try:
            eliminar_detalle_presupuesto(detalle.id)

            messages.success(
                request,
                "Detalle eliminado correctamente."
            )

        except ValueError as error:
            messages.error(request, str(error))

    if presupuesto.recepcion_id:
        return redirect(
            "presupuestos_recepcion",
            recepcion_id=presupuesto.recepcion_id
        )

    return redirect(
        "presupuestos_orden",
        orden_id=presupuesto.orden_id
    )


@requiere_roles(*ROLES_GESTION)
def ir_a_presupuesto_vehiculo(request, patente):

    vehiculo = _get_obj(request, Vehiculo, patente=patente)

    orden = (
        OrdenTrabajo.objects
        .filter(vehiculo=vehiculo)
        .select_related("recepcion")
        .order_by("-id")
        .first()
    )

    if not orden:
        messages.error(
            request,
            "El vehículo todavía no tiene órdenes de trabajo."
        )
        return redirect(
            "detalle_vehiculo",
            patente=vehiculo.patente
        )

    # Si la orden tiene una recepción, mostramos
    # los presupuestos reales de esa recepción.
    if orden.recepcion_id:
        return redirect(
            "presupuestos_recepcion",
            recepcion_id=orden.recepcion_id
        )

    # Compatibilidad con órdenes antiguas
    return redirect(
        "presupuestos_orden",
        orden_id=orden.id
    )




@require_POST
@requiere_roles(*ROLES_GESTION)
def generar_nueva_version(request, recepcion_id):

    _get_obj(request, RecepcionVehiculo, pk=recepcion_id)

    try:
        nuevo_presupuesto = crear_version_presupuesto(recepcion_id)

        messages.success(
            request,
            f"¡Se ha generado la versión {nuevo_presupuesto.version} correctamente!"
        )

    except ValueError as e:
        messages.error(request, str(e))

    return redirect(
        "presupuestos_recepcion",
        recepcion_id=recepcion_id
    )


@require_POST
@requiere_roles(*ROLES_GESTION)
def selectEstado(request, presupuesto_id):

    presupuesto = _get_obj(request, Presupuesto,
        pk=presupuesto_id
    )

    estado_seleccionado = request.POST.get("inputGroupEstado")

    try:

        if estado_seleccionado == "PENDIENTE":
            enviar_presupuesto(presupuesto.id)

        elif estado_seleccionado == "APROBADO":
            aprobar_presupuesto(presupuesto.id)

        elif estado_seleccionado == "RECHAZADO":
            rechazar_presupuesto(presupuesto.id)

        else:
            raise ValueError("Estado seleccionado no válido.")

        messages.success(
            request,
            f"Presupuesto actualizado a {estado_seleccionado}."
        )

    except ValueError as error:

        messages.error(request, str(error))

    # Redirigir según el origen del presupuesto
    if presupuesto.recepcion_id:
        return redirect(
            "presupuestos_recepcion",
            recepcion_id=presupuesto.recepcion_id
        )

    return redirect(
        "presupuestos_orden",
        orden_id=presupuesto.orden_id
    )

@requiere_roles(*ROLES_GESTION)
def presupuestos_orden(request, orden_id):

    orden = _get_obj(request, OrdenTrabajo, pk=orden_id)

    presupuestos = (
        orden.presupuestos
        .prefetch_related("detalles")
        .order_by("-version")
    )

    return render(
        request,
        "presupuestos.html",
        {
            "orden": orden,
            "presupuestos": presupuestos,
        }
    )

@requiere_roles(*ROLES_GESTION)
def nueva_recepcion(request):

    if request.method == "POST":

        form = RecepcionVehiculoForm(request.POST)
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())
        form.fields["vehiculo"].queryset = _scope(request, Vehiculo.objects.all())

        if form.is_valid():

            recepcion = form.save(commit=False)
            recepcion.taller_id = _taller_para_nuevo_registro(request, recepcion.cliente)
            recepcion.save()

            try:
                presupuesto = crear_version_presupuesto(recepcion.id)

                messages.success(
                    request,
                    "Recepción registrada y presupuesto inicial creado correctamente."
                )

                return redirect(
                    "presupuestos_recepcion",
                    recepcion_id=recepcion.id
                )

            except ValueError as error:

                messages.error(request, str(error))

    else:
        form = RecepcionVehiculoForm()
        form.fields["cliente"].queryset = _scope(request, Cliente.objects.all())
        form.fields["vehiculo"].queryset = _scope(request, Vehiculo.objects.all())

    return render(
        request,
        "recepciones/nueva_recepcion.html",
        {
            "form": form
        }
    )