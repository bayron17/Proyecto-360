from django.db import models
from django.db.models import Q
from django.core.validators import MinValueValidator
from decimal import Decimal
from django.core.exceptions import ValidationError
from django.conf import settings


class Cliente(models.Model):
    taller = models.ForeignKey(
        "talleres.Taller", on_delete=models.PROTECT,
        related_name="clientes", null=True, blank=True
    )
    rut = models.CharField(max_length=12, unique=True)
    nombre = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    direccion = models.CharField(max_length=150, blank=True)
    fecha_registro = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombre} - {self.rut}"


class Vehiculo(models.Model):
    taller = models.ForeignKey(
        "talleres.Taller", on_delete=models.PROTECT,
        related_name="vehiculos", null=True, blank=True
    )
    cliente = models.ForeignKey(
        Cliente,
        on_delete=models.CASCADE,
        related_name="vehiculos"
    )
    patente = models.CharField(max_length=10, unique=True)
    marca = models.CharField(max_length=50)
    modelo = models.CharField(max_length=50)
    anio = models.PositiveIntegerField()
    color = models.CharField(max_length=30, blank=True)
    kilometraje = models.PositiveIntegerField(default=0)
    vin = models.CharField(max_length=17, blank=True)

    def clean(self):
        super().clean()
        if self.taller_id and self.cliente_id and self.cliente.taller_id != self.taller_id:
            raise ValidationError("El cliente no pertenece al taller del vehículo.")

    def __str__(self):
        return f"{self.marca} {self.modelo} - {self.patente}"


class RecepcionVehiculo(models.Model):
    taller = models.ForeignKey(
        "talleres.Taller", on_delete=models.PROTECT,
        related_name="recepciones", null=True, blank=True
    )

    cliente = models.ForeignKey(
        Cliente,
        on_delete=models.PROTECT,
        related_name="recepciones"
    )

    vehiculo = models.ForeignKey(
        Vehiculo,
        on_delete=models.PROTECT,
        related_name="recepciones"
    )

    fecha_ingreso = models.DateTimeField(auto_now_add=True)

    kilometraje_ingreso = models.PositiveIntegerField()

    motivo_ingreso = models.TextField()

    observaciones = models.TextField(blank=True)

    def clean(self):
        super().clean()
        if self.cliente_id and self.vehiculo_id:
            if self.vehiculo.cliente_id != self.cliente_id:
                raise ValidationError(
                    "El vehículo seleccionado no pertenece al cliente."
                )
            if self.taller_id and self.vehiculo.taller_id != self.taller_id:
                raise ValidationError(
                    "El vehículo no pertenece al taller de esta recepción."
                )
            if self.taller_id and self.cliente.taller_id != self.taller_id:
                raise ValidationError(
                    "El cliente no pertenece al taller de esta recepción."
                )

    def __str__(self):
        return f"Recepción #{self.id} - {self.vehiculo.patente}"

class OrdenTrabajo(models.Model):
    taller = models.ForeignKey(
        "talleres.Taller", on_delete=models.PROTECT,
        related_name="ordenes_trabajo", null=True, blank=True
    )
    mecanico_asignado = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
        related_name="ordenes_asignadas", null=True, blank=True
    )

    ESTADOS = [
        ("RECEPCION", "Recepción"),
        ("DIAGNOSTICO", "Diagnóstico"),
        ("PRESUPUESTO", "Presupuesto"),
        ("ESPERANDO_APROBACION", "Esperando aprobación"),
        ("APROBADO", "Aprobado"),
        ("EN_REPARACION", "En reparación"),
        ("ESPERANDO_REPUESTO", "Esperando repuesto"),
        ("CONTROL", "Control de calidad"),
        ("LISTO", "Listo para entrega"),
        ("ENTREGADO", "Entregado"),
        ("CANCELADO", "Cancelado"),
    ]

    recepcion = models.OneToOneField(
        RecepcionVehiculo,
        on_delete=models.PROTECT,
        related_name="orden_trabajo",
        null=True,
        blank=True
    )

    presupuesto = models.OneToOneField(
        "Presupuesto",
        on_delete=models.PROTECT,
        related_name="orden_trabajo",
        null=True,
        blank=True
    )

    cliente = models.ForeignKey(
        Cliente,
        on_delete=models.PROTECT,
        related_name="ordenes"
    )

    vehiculo = models.ForeignKey(
        Vehiculo,
        on_delete=models.PROTECT,
        related_name="ordenes"
    )

    fecha_ingreso = models.DateTimeField(auto_now_add=True)
    kilometraje_ingreso = models.PositiveIntegerField()

    motivo_ingreso = models.TextField()
    observaciones = models.TextField(blank=True)

    estado = models.CharField(
        max_length=30,
        choices=ESTADOS,
        default="RECEPCION"
    )

    fecha_entrega = models.DateTimeField(null=True, blank=True)

    fecha_actualizacion = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"OT-{self.id:04d} - {self.vehiculo.patente}"

class Presupuesto(models.Model):
    taller = models.ForeignKey(
        "talleres.Taller", on_delete=models.PROTECT,
        related_name="presupuestos", null=True, blank=True
    )

    ESTADOS = [
        ("BORRADOR", "Borrador"),
        ("PENDIENTE", "Pendiente de aprobación"),
        ("APROBADO", "Aprobado"),
        ("RECHAZADO", "Rechazado"),
        ("REEMPLAZADO", "Reemplazado"),
    ]

    # Relación con la recepción
    recepcion = models.ForeignKey(
        RecepcionVehiculo,
        on_delete=models.PROTECT,
        related_name="presupuestos",
        null=True,
        blank=True
    )

    # Relación antigua con la orden (temporal)
    orden = models.ForeignKey(
        OrdenTrabajo,
        on_delete=models.PROTECT,
        related_name="presupuestos",
        null=True,
        blank=True
    )

    version = models.PositiveIntegerField()

    estado = models.CharField(
        max_length=20,
        choices=ESTADOS,
        default="BORRADOR"
    )

    fecha_creacion = models.DateTimeField(
        auto_now_add=True
    )

    observaciones = models.TextField(blank=True)

    class Meta:
        ordering = ["-version"]

        constraints = [
            models.UniqueConstraint(
                fields=["orden", "version"],
                name="version_unica_por_orden"
            ),
            models.UniqueConstraint(
                fields=["orden"],
                condition=Q(estado="APROBADO"),
                name="un_aprobado_por_orden"
            ),
            models.UniqueConstraint(
                fields=["recepcion", "version"],
                condition=Q(recepcion__isnull=False),
                name="version_unica_por_recepcion"
            ),
            models.UniqueConstraint(
                fields=["recepcion"],
                condition=Q(
                    estado="APROBADO",
                    recepcion__isnull=False
                ),
                name="un_aprobado_por_recepcion"
            ),
        ]

    @property
    def total(self):
        return sum(
            (detalle.subtotal for detalle in self.detalles.all()),
            Decimal("0.00")
        )

    def __str__(self):
        return (
            f"Presupuesto v{self.version} "
            f"- Orden #{self.orden_id}"
        )

    
class DetallePresupuesto(models.Model):

    TIPOS = [
        ("REPUESTO", "Repuesto"),
        ("MANO_OBRA", "Mano de obra"),
        ("SERVICIO", "Servicio"),
    ]

    presupuesto = models.ForeignKey(
        Presupuesto,
        on_delete=models.CASCADE,
        related_name="detalles"
    )

    estado = models.CharField(
        max_length=20,
        choices=TIPOS
    )

    descripcion = models.CharField(
        max_length=255
    )

    cantidad = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[
            MinValueValidator(Decimal("0.01"))
        ]
    )

    precio_unitario = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[
            MinValueValidator(Decimal("0.00"))
        ]
    )

    # @property permite consultar el subtotal como si fuera un atributo
    @property
    def subtotal(self):
        return self.cantidad * self.precio_unitario

    def save(self, *args, **kwargs):
        if self.presupuesto.estado != "BORRADOR":
            raise ValueError(
                "No se pueden modificar detalles "
                "de un presupuesto que no está en borrador."
            )

        super().save(*args, **kwargs)

    
    def delete(self, *args, **kwargs):

        if self.presupuesto.estado != "BORRADOR":
            raise ValueError(
                "No se pueden eliminar detalles "
                "de un presupuesto que no está en borrador."
            )

        return super().delete(*args, **kwargs)

    def __str__(self):
        return self.descripcion
