
from django.urls import path
from . import views
# from .views import base, detalle_orden


urlpatterns = [

    path("", views.base, name="inicio"),
    path("panel-operativo/", views.dashboard, name="dashboard_operativo"),
    path("orden/<int:id>/", views.detalle_orden, name="detalle_orden"),
    path("orden/nueva/", views.nueva_orden, name="nueva_orden"),
    path("ordenes/<int:id>/editar/", views.editar_orden, name="editar_orden"),
    path( "ordenes/<int:id>/eliminar/", views.eliminar_orden, name="eliminar_orden"),
    path("clientes/", views.lista_clientes, name="lista_clientes"),
    path("clientes/nuevo/", views.nuevo_cliente, name="nuevo_cliente"),
    path("clientes/<int:id>/", views.detalle_cliente, name="detalle_cliente"),
    path("clientes/<int:id>/editar/", views.editar_cliente, name="editar_cliente"),
    path("clientes/<int:id>/eliminar/", views.eliminar_cliente, name="eliminar_cliente"),
    path("vehiculos/", views.lista_vehiculos, name="lista_vehiculos"),
    path("vehiculos/nuevo/", views.nuevo_vehiculo, name="nuevo_vehiculo"),
    path("vehiculos/<str:patente>/editar/", views.editar_vehiculo, name="editar_vehiculo"),
    path("vehiculos/<str:patente>/eliminar/", views.eliminar_vehiculo, name="eliminar_vehiculo"),
    path("vehiculos/<str:patente>/", views.detalle_vehiculo, name="detalle_vehiculo"),
    path("vehiculos/<str:patente>/presupuesto/gestion/", views.ir_a_presupuesto_vehiculo, name="ir_a_presupuesto_vehiculo"),
    path("api/consultar-patente/", views.consultar_patente, name="consultar_patente"),
    path("orden/<int:orden_id>/presupuestos/", views.presupuestos_orden, name="presupuestos_orden"),
    path("recepcion/<int:recepcion_id>/presupuestos/", views.presupuestos_recepcion, name="presupuestos_recepcion"),
    path("recepcion/<int:recepcion_id>/presupuesto/nueva-version/", views.generar_nueva_version, name="crear_version_presupuesto"),
    path("presupuesto/<int:presupuesto_id>/agregar-detalle/", views.agregar_detalle, name="agregar_detalle" ),
    path("detalle/<int:detalle_id>/editar/", views.editar_detalle, name="editar_detalle"),
    path("detalle/<int:detalle_id>/eliminar/", views.eliminar_detalle, name="eliminar_detalle"),
    path("presupuesto/<int:presupuesto_id>/estado/", views.selectEstado, name="select_estado" ),
    path("entregas/", views.entregas_view, name="entregas"),
    path("recepcion/nueva/", views.nueva_recepcion, name="nueva_recepcion"),
    
]
