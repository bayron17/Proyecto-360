
from django.test import TestCase

from .models import (
    Cliente,
    Vehiculo,
    RecepcionVehiculo,
    OrdenTrabajo,
    Presupuesto,
    DetallePresupuesto,
)

from .services import (
    agregar_detalle_presupuesto,
    crear_version_presupuesto,
    editar_detalle_presupuesto,
    eliminar_detalle_presupuesto,
    aprobar_presupuesto,
    enviar_presupuesto,
    rechazar_presupuesto,

)

from decimal import Decimal


class PresupuestoTestCase(TestCase):

    def setUp(self):

        # 1. Crear cliente de prueba
        self.cliente = Cliente.objects.create(
            rut="11111111-1",
            nombre="Cliente de prueba",
            telefono="912345678",
            email="prueba@test.com",
            direccion="Santiago"
        )

        # 2. Crear vehículo
        self.vehiculo = Vehiculo.objects.create(
            cliente=self.cliente,
            patente="TEST11",
            marca="Toyota",
            modelo="Yaris",
            anio=2020,
            color="Blanco",
            kilometraje=50000
        )

        # 3. Crear recepción del vehículo
        self.recepcion = RecepcionVehiculo.objects.create(
            cliente=self.cliente,
            vehiculo=self.vehiculo,
            kilometraje_ingreso=50000,
            motivo_ingreso="Mantención general",
            observaciones="Recepción de prueba"
        )

        # 4. Crear presupuesto asociado a la recepción
        self.presupuesto = Presupuesto.objects.create(
            recepcion=self.recepcion,
            version=1,
            estado="BORRADOR"
        )

        # 5. Crear detalle inicial
        self.detalle = DetallePresupuesto.objects.create(
            presupuesto=self.presupuesto,
            estado="REPUESTO",
            descripcion="Filtro de aceite",
            cantidad=1,
            precio_unitario=12000
        )

    # ==========================================
    # AGREGAR DETALLES
    # ==========================================

    def test_agregar_detalle(self):

        detalle = agregar_detalle_presupuesto(
            self.presupuesto.id,
            {
                "estado": "REPUESTO",
                "descripcion": "Pastillas de freno",
                "cantidad": Decimal("1"),
                "precio_unitario": Decimal("35000")
            }
        )

        self.assertEqual(
            detalle.descripcion,
            "Pastillas de freno"
        )

        self.assertEqual(
            self.presupuesto.detalles.count(),
            2
        )

    # ==========================================
    # EDITAR DETALLES
    # ==========================================

    def test_editar_detalle(self):

        editar_detalle_presupuesto(
            self.detalle.id,
            {
                "estado": "REPUESTO",
                "descripcion": "Filtro nuevo",
                "cantidad": Decimal("2"),
                "precio_unitario": Decimal("15000")
            }
        )

        self.detalle.refresh_from_db()

        self.assertEqual(
            self.detalle.descripcion,
            "Filtro nuevo"
        )

        self.assertEqual(
            self.detalle.cantidad,
            Decimal("2")
        )

    # ==========================================
    # ELIMINAR DETALLES
    # ==========================================

    def test_eliminar_detalle(self):

        eliminar_detalle_presupuesto(
            self.detalle.id
        )

        self.assertFalse(
            DetallePresupuesto.objects.filter(
                pk=self.detalle.id
            ).exists()
        )

    # ==========================================
    # RESTRICCIONES DE PRESUPUESTOS APROBADOS
    # ==========================================

    def test_no_agregar_detalle_a_presupuesto_aprobado(self):

        self.presupuesto.estado = "APROBADO"
        self.presupuesto.save(update_fields=["estado"])

        with self.assertRaises(ValueError):

            agregar_detalle_presupuesto(
                self.presupuesto.id,
                {
                    "estado": "REPUESTO",
                    "descripcion": "Batería",
                    "cantidad": Decimal("1"),
                    "precio_unitario": Decimal("50000")
                }
            )

    def test_no_editar_detalle_de_presupuesto_aprobado(self):

        self.presupuesto.estado = "APROBADO"
        self.presupuesto.save(update_fields=["estado"])

        with self.assertRaises(ValueError):

            editar_detalle_presupuesto(
                self.detalle.id,
                {
                    "estado": "REPUESTO",
                    "descripcion": "Filtro modificado",
                    "cantidad": Decimal("1"),
                    "precio_unitario": Decimal("20000")
                }
            )

    def test_no_eliminar_detalle_de_presupuesto_aprobado(self):

        self.presupuesto.estado = "APROBADO"
        self.presupuesto.save(update_fields=["estado"])

        with self.assertRaises(ValueError):

            eliminar_detalle_presupuesto(
                self.detalle.id
            )

    # ==========================================
    # CREACIÓN DE NUEVAS VERSIONES
    # ==========================================

    def test_crear_segunda_version(self):

        nueva = crear_version_presupuesto(
            self.recepcion.id
        )

        self.assertEqual(nueva.version, 2)
        self.assertEqual(nueva.estado, "BORRADOR")

        # Comprobamos que pertenece a la misma recepción
        self.assertEqual(
            nueva.recepcion_id,
            self.recepcion.id
        )

        # Comprobamos que el presupuesto anterior sigue existiendo
        self.assertTrue(
            Presupuesto.objects.filter(
                id=self.presupuesto.id
            ).exists()
        )

    # ==========================================
    # COPIAR DETALLES A UNA NUEVA VERSIÓN
    # ==========================================

    def test_copiar_detalles_a_nueva_version(self):

        nueva = crear_version_presupuesto(
            self.recepcion.id
        )

        detalle_nuevo = nueva.detalles.first()

        self.assertIsNotNone(detalle_nuevo)

        self.assertEqual(
            detalle_nuevo.descripcion,
            "Filtro de aceite"
        )

        self.assertEqual(
            detalle_nuevo.cantidad,
            Decimal("1")
        )

        self.assertEqual(
            detalle_nuevo.precio_unitario,
            Decimal("12000")
        )

        # Comprobamos que son registros independientes
        self.assertNotEqual(
            detalle_nuevo.id,
            self.detalle.id
        )


    # ==========================================
    # APROBACIÓN Y GENERACIÓN DE ÓRDENES
    # ==========================================

    def test_aprobar_presupuesto_crea_orden(self):

        # Comprobamos que todavía no existe una orden
        self.assertEqual(
            OrdenTrabajo.objects.filter(
                recepcion=self.recepcion
            ).count(),
            0
        )

        # Enviamos el presupuesto para aprobación
        self.presupuesto.estado = "PENDIENTE"
        self.presupuesto.save(update_fields=["estado"])

        # Aprobamos el presupuesto
        aprobar_presupuesto(self.presupuesto.id)

        self.presupuesto.refresh_from_db()

        # Comprobamos que quedó aprobado
        self.assertEqual(
            self.presupuesto.estado,
            "APROBADO"
        )

        # Comprobamos que se creó una orden
        orden = OrdenTrabajo.objects.get(
            recepcion=self.recepcion
        )

        self.assertEqual(
            orden.presupuesto_id,
            self.presupuesto.id
        )

        self.assertEqual(
            orden.cliente_id,
            self.cliente.id
        )

        self.assertEqual(
            orden.vehiculo_id,
            self.vehiculo.id
        )

    def test_no_aprobar_presupuesto_en_borrador(self):

        # El presupuesto permanece en borrador
        self.assertEqual(
            self.presupuesto.estado,
            "BORRADOR"
        )

        # Intentamos aprobarlo
        with self.assertRaises(ValueError):
            aprobar_presupuesto(self.presupuesto.id)

        # Comprobamos que no se creó ninguna orden
        self.assertEqual(
            OrdenTrabajo.objects.filter(
                recepcion=self.recepcion
            ).count(),
            0
        )

    def test_no_generar_dos_ordenes_para_una_recepcion(self):

        # Enviamos el presupuesto
        self.presupuesto.estado = "PENDIENTE"
        self.presupuesto.save(update_fields=["estado"])

        # Primera aprobación: debe crear una orden
        aprobar_presupuesto(self.presupuesto.id)

        self.assertEqual(
            OrdenTrabajo.objects.filter(
                recepcion=self.recepcion
            ).count(),
            1
        )

        # Intentamos aprobar nuevamente el mismo presupuesto
        with self.assertRaises(ValueError):
            aprobar_presupuesto(self.presupuesto.id)

        # Comprobamos que sigue existiendo una sola orden
        self.assertEqual(
            OrdenTrabajo.objects.filter(
                recepcion=self.recepcion
            ).count(),
            1
        )

    def test_enviar_presupuesto(self):
        enviar_presupuesto(self.presupuesto.id)

        self.presupuesto.refresh_from_db()

        self.assertEqual(self.presupuesto.estado, "PENDIENTE")
        self.assertEqual(
            OrdenTrabajo.objects.filter(recepcion=self.recepcion).count(),
            0
        )

    def test_no_enviar_presupuesto_sin_detalles(self):
        self.presupuesto.detalles.all().delete()

        with self.assertRaises(ValueError):
            enviar_presupuesto(self.presupuesto.id)

        self.presupuesto.refresh_from_db()
        self.assertEqual(self.presupuesto.estado, "BORRADOR")

    def test_rechazar_presupuesto(self):
        self.presupuesto.estado = "PENDIENTE"
        self.presupuesto.save(update_fields=["estado"])

        rechazar_presupuesto(self.presupuesto.id)

        self.presupuesto.refresh_from_db()

        self.assertEqual(self.presupuesto.estado, "RECHAZADO")
        self.assertEqual(
            OrdenTrabajo.objects.filter(recepcion=self.recepcion).count(),
            0
        )

    def test_crear_version_despues_de_rechazo(self):
        self.presupuesto.estado = "RECHAZADO"
        self.presupuesto.save(update_fields=["estado"])

        nueva = crear_version_presupuesto(self.recepcion.id)

        self.assertEqual(nueva.version, 2)
        self.assertEqual(nueva.estado, "BORRADOR")
        self.assertTrue(
            Presupuesto.objects.filter(pk=self.presupuesto.id).exists()
        )

    def test_no_crear_version_si_ya_existe_orden(self):
        self.presupuesto.estado = "PENDIENTE"
        self.presupuesto.save(update_fields=["estado"])

        aprobar_presupuesto(self.presupuesto.id)

        with self.assertRaises(ValueError):
            crear_version_presupuesto(self.recepcion.id)

        self.assertEqual(
            Presupuesto.objects.filter(recepcion=self.recepcion).count(),
            1
        )