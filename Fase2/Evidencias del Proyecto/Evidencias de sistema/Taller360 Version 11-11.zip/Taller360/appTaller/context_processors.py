from .models import OrdenTrabajo


def contador_ordenes(request):
    total = 0
    if request.user.is_authenticated:
        ordenes = OrdenTrabajo.objects.exclude(
            estado__in=["ENTREGADO", "CANCELADO"]
        )
        if request.user.rol != "SUPERADMIN":
            if request.user.taller_id:
                ordenes = ordenes.filter(taller_id=request.user.taller_id)
            else:
                ordenes = ordenes.none()
        total = ordenes.count()
    return {"contador_ordenes_activas": total}
