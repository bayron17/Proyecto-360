
from django.db import transaction
from django.db.models import Max
from decimal import Decimal

from .models import (
    OrdenTrabajo,
    Presupuesto,
    DetallePresupuesto,
    RecepcionVehiculo
)

# Utilizamos transaction.atomic para agrupar la operación en una transacción.

@transaction.atomic
def crear_version_presupuesto(recepcion_id):

    # Buscamos y bloqueamos la recepción
    recepcion = RecepcionVehiculo.objects.select_for_update().get(
        pk=recepcion_id
    )

    # Evitamos crear presupuestos después de generar la orden
    if OrdenTrabajo.objects.filter(recepcion=recepcion).exists():
        raise ValueError(
            "Esta recepción ya tiene una orden de trabajo. "
            "No se pueden crear nuevas versiones de presupuesto."
        )

    # Buscamos la última versión de esta recepción
    anterior = (
        Presupuesto.objects.filter(recepcion=recepcion)
        .order_by("-version")
        .first()
    )

    # Calculamos la nueva versión
    nueva_version = anterior.version + 1 if anterior else 1

    # Creamos el presupuesto sin asociarlo a una orden
    nuevo = Presupuesto.objects.create(
        recepcion=recepcion,
        taller=recepcion.taller,
        version=nueva_version,
        estado="BORRADOR",
        observaciones=anterior.observaciones if anterior else ""
    )

    # Copiamos los detalles de la versión anterior
    if anterior:
        for detalle in anterior.detalles.all():

            DetallePresupuesto.objects.create(
                presupuesto=nuevo,
                estado=detalle.estado,
                descripcion=detalle.descripcion,
                cantidad=detalle.cantidad,
                precio_unitario=detalle.precio_unitario
            )

    return nuevo



@transaction.atomic
def enviar_presupuesto(presupuesto_id):

    presupuesto = Presupuesto.objects.select_for_update().get(
        pk=presupuesto_id
    )

    if presupuesto.estado != "BORRADOR":
        raise ValueError(
            "Solo se pueden enviar presupuestos en borrador."
        )

    # Comprobamos las versiones según su relación
    if presupuesto.recepcion_id:

        existe_version_nueva = Presupuesto.objects.filter(
            recepcion_id=presupuesto.recepcion_id,
            version__gt=presupuesto.version
        ).exists()

    elif presupuesto.orden_id:

        existe_version_nueva = Presupuesto.objects.filter(
            orden_id=presupuesto.orden_id,
            version__gt=presupuesto.version
        ).exists()

    else:
        raise ValueError(
            "El presupuesto no está asociado a una recepción ni a una orden."
        )

    if existe_version_nueva:
        raise ValueError(
            "No puedes enviar una versión antigua."
        )

    if not presupuesto.detalles.exists():
        raise ValueError(
            "El presupuesto debe tener al menos un detalle."
        )

    presupuesto.estado = "PENDIENTE"
    presupuesto.save(update_fields=["estado"])

    return presupuesto


@transaction.atomic
def aprobar_presupuesto(presupuesto_id):

    # 1. Buscamos y bloqueamos el presupuesto
    presupuesto = Presupuesto.objects.select_for_update().get(
            pk=presupuesto_id
    )

    bloquear_origen_presupuesto(presupuesto)

   
    # 2. Solo permitimos aprobar presupuestos pendientes
    if presupuesto.estado != "PENDIENTE":
        raise ValueError(
            "Solo se pueden aprobar presupuestos pendientes."
        )

    # 3. Verificamos que tenga al menos un detalle
    if not presupuesto.detalles.exists():
        raise ValueError(
            "No se puede aprobar un presupuesto sin detalles."
        )


    # Primero comprobamos orden_id porque los presupuestos
    # históricos pueden tener también una recepción asociada.

    if presupuesto.orden_id:

        orden = OrdenTrabajo.objects.select_for_update().get(
            pk=presupuesto.orden_id
        )

        # No permitimos aprobar versiones antiguas
        if Presupuesto.objects.filter(
            orden=orden,
            version__gt=presupuesto.version
        ).exists():
            raise ValueError(
                "No se puede aprobar una versión antigua."
            )

        # Reemplazamos el presupuesto aprobado anterior
        anterior_aprobado = Presupuesto.objects.filter(
            orden=orden,
            estado="APROBADO"
        ).exclude(pk=presupuesto.pk).first()

        if anterior_aprobado:
            anterior_aprobado.estado = "REEMPLAZADO"
            anterior_aprobado.save(update_fields=["estado"])

        presupuesto.estado = "APROBADO"
        presupuesto.save(update_fields=["estado"])

        return presupuesto


    if presupuesto.recepcion_id:

        # Bloqueamos la recepción
        recepcion = RecepcionVehiculo.objects.select_for_update().get(
            pk=presupuesto.recepcion_id
        )

        # Comprobamos que no exista una orden
        if OrdenTrabajo.objects.filter(
            recepcion=recepcion
        ).exists():
            raise ValueError(
                "Esta recepción ya tiene una orden de trabajo."
            )

        # Comprobamos que sea la última versión
        if Presupuesto.objects.filter(
            recepcion=recepcion,
            version__gt=presupuesto.version
        ).exists():
            raise ValueError(
                "No se puede aprobar una versión antigua."
            )

        # Aprobamos el presupuesto
        presupuesto.estado = "APROBADO"
        presupuesto.save(update_fields=["estado"])

        # Creamos automáticamente la orden de trabajo
        orden = OrdenTrabajo.objects.create(
            recepcion=recepcion,
            presupuesto=presupuesto,
            taller=recepcion.taller,
            cliente=recepcion.cliente,
            vehiculo=recepcion.vehiculo,
            kilometraje_ingreso=recepcion.kilometraje_ingreso,
            motivo_ingreso=recepcion.motivo_ingreso,
            observaciones=recepcion.observaciones,
            estado="Recepcion"
        )

        return presupuesto

    # ==========================================
    # CASO 3: PRESUPUESTO SIN ASOCIACIÓN
    # ==========================================

    raise ValueError(
        "El presupuesto no está asociado a una recepción ni a una orden."
    )



@transaction.atomic
def rechazar_presupuesto(presupuesto_id):

    presupuesto = Presupuesto.objects.select_for_update().get(
        pk=presupuesto_id
    )

    if presupuesto.estado != "PENDIENTE":
        raise ValueError(
            "Solo se pueden rechazar presupuestos pendientes."
        )

    if presupuesto.recepcion_id:

        recepcion = RecepcionVehiculo.objects.select_for_update().get(
            pk=presupuesto.recepcion_id
        )

        existe_version_nueva = Presupuesto.objects.filter(
            recepcion=recepcion,
            version__gt=presupuesto.version
        ).exists()

    elif presupuesto.orden_id:

        orden = OrdenTrabajo.objects.select_for_update().get(
            pk=presupuesto.orden_id
        )

        existe_version_nueva = Presupuesto.objects.filter(
            orden=orden,
            version__gt=presupuesto.version
        ).exists()

    else:
        raise ValueError(
            "El presupuesto no está asociado a una recepción ni a una orden."
        )

    if existe_version_nueva:
        raise ValueError(
            "No se puede rechazar una versión antigua."
        )

    presupuesto.estado = "RECHAZADO"
    presupuesto.save(update_fields=["estado"])

    return presupuesto



@transaction.atomic
def actualizar_precio_detalle(detalle_id, nuevo_precio):

    # Identificamos el detalle y su presupuesto
    detalle = DetallePresupuesto.objects.get(
        pk=detalle_id
    )

    OrdenTrabajo.objects.select_for_update().get(
        pk=detalle.presupuesto.orden_id
    )

    # Recuperamos el detalle actualizado
    detalle.refresh_from_db()

    if detalle.presupuesto.estado != "BORRADOR":
        raise ValueError(
            "No se puede modificar un presupuesto "
            "que no está en borrador."
        )

    precio = Decimal(str(nuevo_precio))

    if not precio.is_finite() or precio < 0:
        raise ValueError(
            "El precio debe ser un número válido y no negativo."
        )

    detalle.precio_unitario = precio
    detalle.full_clean()
    detalle.save(update_fields=["precio_unitario"])

    return detalle


def bloquear_origen_presupuesto(presupuesto):

    #  Presupuesto nuevo asociado a una recepción
    if presupuesto.recepcion_id:

        RecepcionVehiculo.objects.select_for_update().get(
            pk=presupuesto.recepcion_id
        )

    #  Presupuesto histórico asociado a una orden
    elif presupuesto.orden_id:

        OrdenTrabajo.objects.select_for_update().get(
            pk=presupuesto.orden_id
        )

    else:
        raise ValueError(
            "El presupuesto no está asociado a una recepción ni a una orden."
        )


@transaction.atomic
def agregar_detalle_presupuesto(presupuesto_id, datos):

    presupuesto = Presupuesto.objects.select_for_update().get(
        pk=presupuesto_id
    )

    bloquear_origen_presupuesto(presupuesto)

    presupuesto.refresh_from_db()

    if presupuesto.estado != "BORRADOR":
        raise ValueError(
            "Solo se pueden agregar detalles a presupuestos en borrador."
        )

    detalle = DetallePresupuesto(
        presupuesto=presupuesto,
        **datos
    )

    detalle.full_clean()

    detalle.save()

    return detalle


@transaction.atomic
def editar_detalle_presupuesto(detalle_id, datos):

    detalle = DetallePresupuesto.objects.get(
        pk=detalle_id
    )

    presupuesto = Presupuesto.objects.select_for_update().get(
        pk=detalle.presupuesto_id
    )

    # Bloqueamos la recepción o la orden asociada
    bloquear_origen_presupuesto(presupuesto)

    presupuesto.refresh_from_db()
    detalle.refresh_from_db()

    if presupuesto.estado != "BORRADOR":
        raise ValueError(
            "Solo se pueden editar detalles de presupuestos en borrador."
        )

    # Actualizamos los datos
    detalle.estado = datos["estado"]
    detalle.descripcion = datos["descripcion"]
    detalle.cantidad = datos["cantidad"]
    detalle.precio_unitario = datos["precio_unitario"]

    detalle.full_clean()
    detalle.save()

    return detalle


@transaction.atomic
def eliminar_detalle_presupuesto(detalle_id):

    detalle = DetallePresupuesto.objects.get(
        pk=detalle_id
    )

    presupuesto = Presupuesto.objects.select_for_update().get(
        pk=detalle.presupuesto_id
    )

    bloquear_origen_presupuesto(presupuesto)

    presupuesto.refresh_from_db()

    if presupuesto.estado != "BORRADOR":
        raise ValueError(
            "Solo se pueden eliminar detalles de presupuestos en borrador."
        )

    detalle.delete()

    return True
