
/* ==========================================
   1. REFERENCIAS DEL DOM
========================================== */

const sidebar = document.getElementById("sidebar");
const openSidebarBtn = document.getElementById("openSidebarBtn");
const closeSidebarBtn = document.getElementById("closeSidebarBtn");
const mobileOverlay = document.getElementById("mobileOverlay");
const navItems = document.querySelectorAll(".nav-item");
const pageTitle = document.getElementById("pageTitle");

// Inicializar iconos Lucide
if (typeof lucide !== "undefined") {
    lucide.createIcons();
}


/* ==========================================
   2. MENÚ LATERAL
========================================== */

function closeMenu() {

    if (sidebar) {
        sidebar.classList.remove("open");
    }

    if (mobileOverlay) {
        mobileOverlay.classList.remove("active");
    }

    document.body.style.overflow = "auto";
}


function openMenu() {

    if (sidebar) {
        sidebar.classList.add("open");
    }

    if (mobileOverlay) {
        mobileOverlay.classList.add("active");
    }

    document.body.style.overflow = "hidden";
}


/* ==========================================
   3. FILTROS DE ÓRDENES
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const enlacesFiltro = document.querySelectorAll(
        "#colBtnFilter a.btn"
    );

    enlacesFiltro.forEach(enlace => {

        enlace.addEventListener("click", function () {

            enlacesFiltro.forEach(btn => {
                btn.classList.remove("active");
            });

            this.classList.add("active");

        });

    });

});


/* ==========================================
   4. CONSULTAR PATENTE
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const btnConsultarPatente = document.getElementById(
        "btnConsultarPatente"
    );

    // Evitar errores si estamos en otra página
    if (!btnConsultarPatente) {
        return;
    }

    btnConsultarPatente.addEventListener(
        "click",
        async function () {

            const inputPatente = document.getElementById(
                "inputPatente"
            );

            const resultado = document.getElementById(
                "resultadoPatente"
            );

            const boton = this;

            // Comprobar que existan los elementos
            if (!inputPatente || !resultado) {
                console.error(
                    "No se encontraron los elementos de consulta."
                );
                return;
            }

            /* ------------------------------
               VALIDAR PATENTE
            ------------------------------ */

            const patente = inputPatente.value
                .trim()
                .toUpperCase()
                .replace(/[\s.-]/g, "");

            if (!patente) {

                resultado.textContent =
                    "Debes ingresar una patente.";

                resultado.style.color = "red";
                return;
            }

            resultado.textContent =
                "Consultando patente...";

            resultado.style.color = "";
            boton.disabled = true;

            try {

                /* ------------------------------
                   CONSULTAR API MEDIANTE DJANGO
                ------------------------------ */

                const rutaConsulta = boton.dataset.url;

                if (!rutaConsulta) {
                    throw new Error(
                        "No se configuró la URL de consulta."
                    );
                }

                const url = rutaConsulta + "?patente=" +
                    encodeURIComponent(patente);

                const respuesta = await fetch(url);

                // Convertir respuesta JSON a objeto JS
                const datos = await respuesta.json();

                console.log(
                    "RESPUESTA COMPLETA:",
                    datos
                );


                /* ------------------------------
                   VERIFICAR ERRORES
                ------------------------------ */

                if (
                    !respuesta.ok ||
                    datos.error ||
                    datos.status === "error"
                ) {

                    resultado.textContent =
                        datos.error ||
                        datos.message ||
                        "No fue posible consultar la patente.";

                    resultado.style.color = "red";
                    return;
                }


                /* ------------------------------
                   EXTRAER INFORMACIÓN
                ------------------------------ */

                const vehiculo = datos.data ?? datos;

                console.log(
                    "DATOS DEL VEHÍCULO:",
                    vehiculo
                );

                if (
                    !vehiculo ||
                    typeof vehiculo !== "object" ||
                    Array.isArray(vehiculo)
                ) {

                    resultado.textContent =
                        "La API no devolvió datos válidos.";

                    resultado.style.color = "red";
                    return;
                }

                console.log(
                    "CLAVES DISPONIBLES:",
                    Object.keys(vehiculo)
                );


                /* ------------------------------
                   IDENTIFICAR CAMPOS
                ------------------------------ */

                const obtenerValor = (...nombres) => {

                    for (const nombre of nombres) {

                        const valor = vehiculo[nombre];

                        if (
                            valor !== undefined &&
                            valor !== null &&
                            valor !== ""
                        ) {
                            return valor;
                        }
                    }

                    return null;
                };


                /* ------------------------------
                   DATOS PARA EL FORMULARIO
                ------------------------------ */

                const valores = {

                    id_patente: obtenerValor(
                        "patente",
                        "plate",
                        "license_plate"
                    ) ?? patente,

                    id_marca: obtenerValor(
                        "marca",
                        "brand",
                        "make"
                    ),

                    id_modelo: obtenerValor(
                        "modelo",
                        "model"
                    ),

                    id_anio: obtenerValor(
                        "año",
                        "anio",
                        "year"
                    ),

                    id_color: obtenerValor(
                        "color",
                        "colour"
                    ),

                    id_vin: obtenerValor(
                        "chasis",
                        "vin",
                        "chassis"
                    )
                };

                console.log(
                    "VALORES IDENTIFICADOS:",
                    valores
                );


                /* ------------------------------
                   AUTOCOMPLETAR FORMULARIO
                ------------------------------ */

                let completados = 0;

                for (
                    const [idCampo, valor]
                    of Object.entries(valores)
                ) {

                    const input = document.getElementById(
                        idCampo
                    );

                    if (
                        input &&
                        valor !== null &&
                        valor !== undefined
                    ) {

                        input.value = valor;

                        input.dispatchEvent(
                            new Event("input", {
                                bubbles: true
                            })
                        );

                        input.dispatchEvent(
                            new Event("change", {
                                bubbles: true
                            })
                        );

                        completados++;
                    }
                }


                /* ------------------------------
                   MOSTRAR RESULTADO
                ------------------------------ */

                if (completados > 1) {

                    resultado.textContent =
                        "Datos del vehículo cargados correctamente.";

                    resultado.style.color = "green";

                } else {

                    resultado.textContent =
                        "Se cargó la patente, pero faltan datos del vehículo. Revisa la consola.";

                    resultado.style.color = "orange";
                }

            } catch (error) {

                console.error(
                    "ERROR AL CONSULTAR:",
                    error
                );

                resultado.textContent =
                    "Ocurrió un error al consultar la patente.";

                resultado.style.color = "red";

            } finally {

                // Habilitar nuevamente el botón
                boton.disabled = false;
            }

        }
    );

});
