from django import forms
from .models import OrdenTrabajo, Cliente, RecepcionVehiculo, Vehiculo , DetallePresupuesto
from cuentas.models import Usuario



class OrdenTrabajoForm(forms.ModelForm):

    class Meta:
        model = OrdenTrabajo
        fields = [
            "cliente",
            "vehiculo",
            "kilometraje_ingreso",
            "motivo_ingreso",
            "observaciones",
            "fecha_entrega",
        ]

        widgets = {
            "cliente": forms.Select(attrs={"class": "form-control"}),
            "vehiculo": forms.Select(attrs={"class": "form-control"}),
            "kilometraje_ingreso": forms.NumberInput(attrs={
                "class": "form-control"
            }),
            "motivo_ingreso": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3
            }),
            "observaciones": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3
            }),
            "fecha_entrega": forms.DateTimeInput(
                format="%Y-%m-%dT%H:%M",
                attrs={
                    "class": "form-control",
                    "type": "datetime-local"
                }),
        }

    def clean(self):
        cleaned_data = super().clean()

        cliente = cleaned_data.get("cliente")
        vehiculo = cleaned_data.get("vehiculo")

        if cliente and vehiculo and vehiculo.cliente_id != cliente.id:
            raise forms.ValidationError(
                "El vehículo seleccionado no pertenece al cliente."
            )

        return cleaned_data

class EditarOrdenTrabajoForm(OrdenTrabajoForm):

    class Meta(OrdenTrabajoForm.Meta):
        fields = OrdenTrabajoForm.Meta.fields + ["estado", "mecanico_asignado"]
        widgets = {
            **OrdenTrabajoForm.Meta.widgets,
            "mecanico_asignado": forms.Select(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["mecanico_asignado"].required = False
        self.fields["mecanico_asignado"].queryset = Usuario.objects.filter(
            rol=Usuario.Rol.MECANICO,
            is_active=True,
        )

class ClienteForm(forms.ModelForm):

    class Meta:
        model = Cliente

        fields = [
            "rut",
            "nombre",
            "telefono",
            "email",
            "direccion",
        ]

        widgets = {
            "rut": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "12.345.678-5"
            }),

            "nombre": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Nombre completo"
            }),

            "telefono": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "+56 9 1234 5678"
            }),

            "email": forms.EmailInput(attrs={
                "class": "form-control",
                "placeholder": "correo@ejemplo.cl"
            }),

            "direccion": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Dirección del cliente"
            }),
        }

    def clean_rut(self):
        rut = self.cleaned_data["rut"].strip().upper()
        rut = rut.replace(".", "").replace("-", "")

        if len(rut) < 2 or not rut[:-1].isdigit():
            raise forms.ValidationError("Ingresa un RUT válido.")

        cuerpo = rut[:-1]
        digito = rut[-1]

        if digito not in "0123456789K":
            raise forms.ValidationError(
                "El dígito verificador no es válido."
            )

        suma = 0
        multiplicador = 2

        for numero in reversed(cuerpo):
            suma += int(numero) * multiplicador
            multiplicador = (
                2 if multiplicador == 7
                else multiplicador + 1
            )

        resultado = 11 - (suma % 11)

        if resultado == 11:
            digito_esperado = "0"
        elif resultado == 10:
            digito_esperado = "K"
        else:
            digito_esperado = str(resultado)

        if digito != digito_esperado:
            raise forms.ValidationError(
                "El RUT ingresado no es válido."
            )

        rut_normalizado = f"{int(cuerpo)}-{digito}"

        if Cliente.objects.filter(
            rut=rut_normalizado
        ).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError(
                "Este RUT ya está registrado en Taller360."
            )

        return rut_normalizado


class VehiculoForm(forms.ModelForm):

    class Meta:
        model = Vehiculo
        fields = [
            "cliente",
            "patente",
            "marca",
            "modelo",
            "anio",
            "color",
            "kilometraje",
            "vin",
        ]

        widgets = {
            "cliente": forms.Select(attrs={"class": "form-control"}),
            "patente": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "ABC123"
            }),
            "marca": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Marca del vehículo"
            }),
            "modelo": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Modelo del vehículo"
            }),
            "anio": forms.NumberInput(attrs={
                "class": "form-control",
                "placeholder": "Año del vehículo"
            }),
            "color": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Color del vehículo"
            }),
            "kilometraje": forms.NumberInput(attrs={
                "class": "form-control",
                "placeholder": "Kilometraje actual"
            }),
            "vin": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Número de VIN (opcional)"
            }),
        }

    def clean_patente(self):
        patente = self.cleaned_data["patente"]
        patente = patente.strip().upper().replace(" ", "").replace("-", "")

        if not patente.isalnum():
            raise forms.ValidationError(
                "La patente debe contener solo letras y números."
            )

        if Vehiculo.objects.filter(patente=patente).exists():
            raise forms.ValidationError(
                "Esta patente ya está registrada."
            )
        return patente


  

class DetallePresupuestoForm(forms.ModelForm):

    class Meta:
        model = DetallePresupuesto

        fields = [
            "estado",
            "descripcion",
            "cantidad",
            "precio_unitario",
        ]

        widgets = {
            "estado": forms.Select(
                attrs={"class": "form-select"}
            ),

            "descripcion": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Ej: Filtro de aceite"
                }
            ),

            "cantidad": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "step": "0.01",
                    "min": "0.01"
                }
            ),

            "precio_unitario": forms.NumberInput(
                attrs={
                    "class": "form-control",
                    "step": "0.01",
                    "min": "0"
                }
            ),
        }


class RecepcionVehiculoForm(forms.ModelForm):

    class Meta:
        model = RecepcionVehiculo

        fields = [
            "cliente",
            "vehiculo",
            "kilometraje_ingreso",
            "motivo_ingreso",
            "observaciones",
        ]

        widgets = {
            "cliente": forms.Select(attrs={
                "class": "form-select"
            }),

            "vehiculo": forms.Select(attrs={
                "class": "form-select"
            }),

            "kilometraje_ingreso": forms.NumberInput(attrs={
                "class": "form-control",
                "min": "0",
                "placeholder": "Kilometraje actual"
            }),

            "motivo_ingreso": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
                "placeholder": "Motivo del ingreso del vehículo"
            }),

            "observaciones": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
                "placeholder": "Observaciones adicionales"
            }),
        }