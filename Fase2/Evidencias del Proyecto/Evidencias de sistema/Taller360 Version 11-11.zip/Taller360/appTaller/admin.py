from django.contrib import admin
from .models import Cliente, Vehiculo, OrdenTrabajo


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = (
        "rut",
        "nombre",
        "telefono",
        "email",
        "fecha_registro",
    )
    search_fields = ("rut", "nombre", "telefono", "email")


@admin.register(Vehiculo)
class VehiculoAdmin(admin.ModelAdmin):
    list_display = (
        "patente",
        "marca",
        "modelo",
        "anio",
        "cliente",
        "kilometraje",
    )
    search_fields = (
        "patente",
        "marca",
        "modelo",
        "cliente__nombre",
        "cliente__rut",
    )
    list_filter = ("marca", "anio")


@admin.register(OrdenTrabajo)
class OrdenTrabajoAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "vehiculo",
        "cliente",
        "estado",
        "fecha_ingreso",
        "kilometraje_ingreso",
    )
    search_fields = (
        "vehiculo__patente",
        "cliente__nombre",
        "cliente__rut",
    )
    list_filter = ("estado", "fecha_ingreso")