from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


def asignar_datos_historicos(apps, schema_editor):
    Taller = apps.get_model('talleres', 'Taller')
    Usuario = apps.get_model('cuentas', 'Usuario')
    Cliente = apps.get_model('appTaller', 'Cliente')
    Vehiculo = apps.get_model('appTaller', 'Vehiculo')
    Recepcion = apps.get_model('appTaller', 'RecepcionVehiculo')
    Orden = apps.get_model('appTaller', 'OrdenTrabajo')
    Presupuesto = apps.get_model('appTaller', 'Presupuesto')

    # La base de prueba existente tiene un superadministrador y datos históricos,
    # pero todavía no tenía un taller. Se crea un taller inicial configurable
    # para mantener esos registros dentro de un espacio de trabajo.
    if Taller.objects.exists():
        taller = Taller.objects.order_by('id').first()
    else:
        admin = Usuario.objects.filter(
            rol='SUPERADMIN', is_superuser=True
        ).order_by('id').first()
        if admin is None:
            return
        taller = Taller.objects.create(
            nombre='Taller Central (configurar datos)',
            rut='00000000-0',
            direccion='Por configurar',
            telefono='Por configurar',
            email=admin.email or 'admin@taller360.local',
            administrador=admin,
            activo=True,
        )

    for Modelo in (Cliente, Vehiculo, Recepcion, Orden, Presupuesto):
        Modelo.objects.filter(taller__isnull=True).update(taller_id=taller.pk)


def revertir_asignacion(apps, schema_editor):
    # No se borran talleres ni datos durante una reversión.
    pass


class Migration(migrations.Migration):
    dependencies = [
        ('appTaller', '0011_presupuesto_version_unica_por_recepcion_and_more'),
        ('cuentas', '0002_usuario_taller'),
        ('talleres', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='cliente', name='taller',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='clientes', to='talleres.taller'),
        ),
        migrations.AddField(
            model_name='vehiculo', name='taller',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='vehiculos', to='talleres.taller'),
        ),
        migrations.AddField(
            model_name='recepcionvehiculo', name='taller',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='recepciones', to='talleres.taller'),
        ),
        migrations.AddField(
            model_name='ordentrabajo', name='taller',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='ordenes_trabajo', to='talleres.taller'),
        ),
        migrations.AddField(
            model_name='ordentrabajo', name='mecanico_asignado',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='ordenes_asignadas', to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='presupuesto', name='taller',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='presupuestos', to='talleres.taller'),
        ),
        migrations.RunPython(asignar_datos_historicos, revertir_asignacion),
    ]
