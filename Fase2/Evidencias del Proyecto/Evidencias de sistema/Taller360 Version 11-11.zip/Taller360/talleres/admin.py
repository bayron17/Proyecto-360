from django.contrib import admin
from .models import Taller


@admin.register(Taller)
class TallerAdmin(admin.ModelAdmin):
    list_display = (
        "nombre",
        "rut",
        "administrador",
        "telefono",
        "activo",
    )

    search_fields = ("nombre", "rut")
    list_filter = ("activo",)
