from django import forms
from django.contrib.auth.forms import UserCreationForm
from cuentas.validadores import validar_rut
from cuentas.models import Usuario
from .models import Taller


class RegistroAdministradorForm(UserCreationForm):

    class Meta:
        model = Usuario

        fields = (
            "username",
            "first_name",
            "last_name",
            "rut",
            "email",
            "telefono",
        )

        labels = {
            "username": "Nombre de usuario",
            "first_name": "Nombres",
            "last_name": "Apellidos",
            "rut": "RUT",
            "email": "Correo electrónico",
            "telefono": "Teléfono",
        }

        help_texts = {
            "username": "Nombre que utilizarás para iniciar sesión.",
        }

    password1 = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput,
        help_text="Ingresa una contraseña segura."
    )

    password2 = forms.CharField(
        label="Confirmar contraseña",
        widget=forms.PasswordInput,
        help_text="Repite la contraseña anterior."
    )

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()

        if Usuario.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError(
                "Este correo electrónico ya está registrado."
            )

        return email

    def clean_rut(self):
        rut = self.cleaned_data.get("rut")

        if not rut:
            raise forms.ValidationError(
                "El RUT del administrador es obligatorio."
            )

        rut = validar_rut(rut)

        if Usuario.objects.filter(rut=rut).exists():
            raise forms.ValidationError(
                "Este RUT ya está registrado."
            )

        return rut
    



class RegistroTallerForm(forms.ModelForm):

    administrador = forms.ModelChoiceField(
        queryset=Usuario.objects.none(),
        label="Administrador del taller",
        empty_label="Seleccione un administrador",
        widget=forms.Select(attrs={"class": "form-control"})
    )

    class Meta:
        model = Taller
        fields = (
            "nombre",
            "rut",
            "direccion",
            "telefono",
            "email",
            "administrador",
        )

        labels = {
            "nombre": "Nombre del taller",
            "rut": "RUT del taller",
            "direccion": "Dirección",
            "telefono": "Teléfono de contacto",
            "email": "Correo electrónico",
        }

        widgets = {
            "nombre": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: Taller Mecánico Central"
            }),
            "rut": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Ej: 76123456-7"
            }),
            "direccion": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Dirección del taller"
            }),
            "telefono": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "+56 9 1234 5678"
            }),
            "email": forms.EmailInput(attrs={
                "class": "form-control",
                "placeholder": "contacto@taller.cl"
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["administrador"].queryset = (
            Usuario.objects.filter(
                rol=Usuario.Rol.ADMIN_TALLER,
                is_active=True
            ).order_by("first_name", "last_name", "username")
        )
        # En el registro inicial el administrador se crea junto con el taller.
        # En la edición se debe seleccionar un administrador existente.
        self.fields["administrador"].required = False

    def clean_administrador(self):
        administrador = self.cleaned_data.get("administrador")
        if administrador and administrador.taller_id and administrador.taller_id != self.instance.pk:
            raise forms.ValidationError("Este administrador ya está asignado a otro taller.")
        return administrador

    def clean_rut(self):
        rut = self.cleaned_data.get("rut")

        if not rut:
            raise forms.ValidationError(
                "El RUT del taller es obligatorio."
            )

        rut = validar_rut(rut)

        if Taller.objects.filter(rut=rut).exclude(
            pk=self.instance.pk
        ).exists():
            raise forms.ValidationError(
                "Ya existe un taller registrado con este RUT."
            )

        return rut
