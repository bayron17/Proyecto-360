from django.urls import path
from . import views

urlpatterns = [
    path(
        "registro/",
        views.registrar_taller,
        name="registrar_taller"
    ),
    path(
    "lista/",
    views.lista_talleres,
    name="lista_talleres"
    ),
    path(
        "editar/<int:taller_id>/",
        views.editar_taller,
        name="editar_taller"
    ),
    path(
        "detalle/<int:taller_id>/",
        views.detalle_taller,
        name="detalle_taller"
    ),

    path(
        "estado/<int:taller_id>/",
        views.cambiar_estado_taller,
        name="cambiar_estado_taller"
    ),

]
