from django.contrib.auth import login
from django.db import transaction
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db.models import Q
from django.contrib import messages

from cuentas.models import Usuario
from .forms import RegistroAdministradorForm, RegistroTallerForm
from .models import Taller


def registrar_taller(request):
    if request.method == "POST":
        usuario_form = RegistroAdministradorForm(
            request.POST,
            prefix="usuario"
        )
        taller_form = RegistroTallerForm(
            request.POST,
            prefix="taller"
        )

        if usuario_form.is_valid() and taller_form.is_valid():
            with transaction.atomic():
                usuario = usuario_form.save(commit=False)
                usuario.rol = Usuario.Rol.ADMIN_TALLER
                usuario.save()

                taller = taller_form.save(commit=False)
                taller.administrador = usuario
                taller.save()
                usuario.taller = taller
                usuario.save(update_fields=["taller"])

            if not request.user.is_authenticated:
                login(request, usuario)
                return redirect("dashboard")
            return redirect("lista_talleres")

    else:
        usuario_form = RegistroAdministradorForm(
            prefix="usuario"
        )
        taller_form = RegistroTallerForm(
            prefix="taller"
        )

    return render(
        request,
        "talleres/registrar_taller.html",
        {
            "usuario_form": usuario_form,
            "taller_form": taller_form,
        }
    )



def _exigir_superadmin(request):
    if not (request.user.is_authenticated and request.user.is_active
            and request.user.rol == Usuario.Rol.SUPERADMIN
            and request.user.is_superuser):
        raise PermissionDenied("Solo el superadministrador puede gestionar talleres.")


@login_required
def lista_talleres(request):
    _exigir_superadmin(request)
    busqueda = request.GET.get("q", "").strip()
    estado = request.GET.get("estado", "")
    talleres = Taller.objects.select_related("administrador").order_by("nombre")
    if busqueda:
        talleres = talleres.filter(
            Q(nombre__icontains=busqueda) | Q(rut__icontains=busqueda)
            | Q(administrador__username__icontains=busqueda)
        )
    if estado == "activos":
        talleres = talleres.filter(activo=True)
    elif estado == "inactivos":
        talleres = talleres.filter(activo=False)
    pagina = Paginator(talleres, 10).get_page(request.GET.get("page"))
    return render(request, "talleres/lista_talleres.html", {
        "talleres": pagina, "busqueda": busqueda, "estado": estado,
        "total_talleres": Taller.objects.count(),
        "talleres_activos": Taller.objects.filter(activo=True).count(),
        "talleres_inactivos": Taller.objects.filter(activo=False).count(),
    })


@login_required
def detalle_taller(request, taller_id):
    _exigir_superadmin(request)
    taller = get_object_or_404(Taller.objects.select_related("administrador"), pk=taller_id)
    return render(request, "talleres/detalle_taller.html", {"taller": taller})


@login_required
def editar_taller(request, taller_id):
    _exigir_superadmin(request)
    taller = get_object_or_404(Taller, pk=taller_id)
    from .forms import RegistroTallerForm
    form = RegistroTallerForm(request.POST or None, instance=taller)
    if request.method == "POST" and form.is_valid():
        administrador_anterior = taller.administrador
        taller_actualizado = form.save(commit=False)
        administrador_seleccionado = form.cleaned_data.get("administrador")
        if administrador_seleccionado:
            taller_actualizado.administrador = administrador_seleccionado
        taller_actualizado.save()
        administrador_nuevo = taller_actualizado.administrador
        if administrador_anterior and administrador_anterior.pk != administrador_nuevo.pk and administrador_anterior.taller_id == taller.pk:
            administrador_anterior.taller = None
            administrador_anterior.save(update_fields=["taller"])
        administrador_nuevo.taller = taller_actualizado
        administrador_nuevo.save(update_fields=["taller"])
        messages.success(request, "Los datos del taller se actualizaron correctamente.")
        return redirect("detalle_taller", taller_id=taller.pk)
    return render(request, "talleres/registrar_taller.html", {
        "taller_form": form, "taller": taller, "modo_edicion": True,
    })


@login_required
def cambiar_estado_taller(request, taller_id):
    _exigir_superadmin(request)
    taller = get_object_or_404(Taller, pk=taller_id)
    if request.method == "POST":
        taller.activo = not taller.activo
        taller.save(update_fields=["activo"])
        messages.success(request, f"El taller {taller.nombre} cambió su estado correctamente.")
        return redirect("detalle_taller", taller_id=taller.pk)
    return render(request, "talleres/confirmar_estado_taller.html", {"taller": taller})
