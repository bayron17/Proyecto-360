from django.urls import path
from . import views

urlpatterns = [
    path("login/", views.TallerLoginView.as_view(), name="login"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path(
        "dashboard/<str:rol>/",
        views.dashboard_por_rol,
        name="dashboard_rol"
    ),
    path("logout/", views.cerrar_sesion, name="logout"),
    path(
    "administradores/",
    views.lista_administradores,
    name="lista_administradores"),
    path(
    "administradores/nuevo/",
    views.crear_administrador,
    name="crear_administrador"),
    path(
        "administradores/editar/<int:usuario_id>/",
        views.editar_administrador,
        name="editar_administrador"
    ),
    path(
        "administradores/detalle/<int:usuario_id>/",
        views.detalle_administrador,
        name="detalle_administrador"
    ),    
    path(
        "administradores/estado/<int:usuario_id>/",
        views.cambiar_estado_administrador,
        name="cambiar_estado_administrador"
    ),
    path(
        "empleados/nuevo/",
        views.crear_empleado,
        name="crear_empleado"
    ),
    path(
        "empleados/",
        views.lista_empleados,
        name="lista_empleados"
    ),
    path(
        "empleados/<int:empleado_id>/editar/",
        views.editar_empleado,
        name="editar_empleado"
    ),
    path(
        "empleados/<int:empleado_id>/estado/",
        views.cambiar_estado_empleado,
        name="cambiar_estado_empleado"
    ),

]
