from django.contrib.auth.views import LoginView
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.contrib.auth import logout
from django.views.decorators.http import require_POST
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect, render
from django.db.models import Count, Q
from django.core.paginator import Paginator
from django.utils import timezone
from django.db.models.functions import TruncDate
from datetime import timedelta  
from talleres.models import Taller
from appTaller.models import Cliente, Vehiculo, OrdenTrabajo
from .models import Usuario
from django.contrib import messages
from django.shortcuts import get_object_or_404
from .forms import EditarAdministradorForm 
from .forms import CrearEmpleadoForm
from .forms import EditarEmpleadoForm

class TallerLoginView(LoginView):
    template_name = "cuentas/login.html"
    redirect_authenticated_user = True

    def get_success_url(self):
        return reverse_lazy("dashboard")



@login_required
def dashboard(request):
    usuario = request.user

    rutas = {
        Usuario.Rol.SUPERADMIN: "superadmin",
        Usuario.Rol.ADMIN_TALLER: "administrador",
        Usuario.Rol.RECEPCION: "recepcionista",
        Usuario.Rol.MECANICO: "mecanico",
        Usuario.Rol.CLIENTE: "cliente",
    }

    if usuario.rol == Usuario.Rol.SUPERADMIN:
        if not usuario.is_superuser:
            raise PermissionDenied

    ruta = rutas.get(usuario.rol)

    if not ruta:
        raise PermissionDenied

    if usuario.rol in (Usuario.Rol.RECEPCION, Usuario.Rol.MECANICO):
        if not usuario.taller_id:
            raise PermissionDenied("Tu cuenta no tiene un taller asignado.")
        return redirect("lista_ordenes")

    return redirect("dashboard_rol", rol=ruta)

@login_required
def dashboard_por_rol(request, rol):

    roles = {
        "superadmin": Usuario.Rol.SUPERADMIN,
        "administrador": Usuario.Rol.ADMIN_TALLER,
        "recepcionista": Usuario.Rol.RECEPCION,
        "mecanico": Usuario.Rol.MECANICO,
        "cliente": Usuario.Rol.CLIENTE,
    }

    rol_requerido = roles.get(rol)

    if rol_requerido is None:
        raise PermissionDenied

    if request.user.rol != rol_requerido:
        raise PermissionDenied

    if rol == "superadmin" and not request.user.is_superuser:
        raise PermissionDenied

    contexto = {
        "titulo": f"Panel {request.user.get_rol_display()}",
        "rol": request.user.get_rol_display(),
    }

    if rol == "superadmin":

        estados_finales = ["ENTREGADO", "CANCELADO"]

        contexto.update({
            "total_talleres": Taller.objects.count(),

            "talleres_activos": Taller.objects.filter(
                activo=True
            ).count(),

            "talleres_inactivos": Taller.objects.filter(
                activo=False
            ).count(),

            "total_administradores": Usuario.objects.filter(
                rol=Usuario.Rol.ADMIN_TALLER
            ).count(),

            "total_clientes": Cliente.objects.count(),

            "total_vehiculos": Vehiculo.objects.count(),

            "total_ordenes": OrdenTrabajo.objects.count(),

            "ordenes_activas": OrdenTrabajo.objects.exclude(
                estado__in=estados_finales
            ).count(),

            "ordenes_entregadas": OrdenTrabajo.objects.filter(
                estado="ENTREGADO"
            ).count(),

            "ultimos_talleres": Taller.objects.select_related(
                "administrador"
            ).order_by("-fecha_registro")[:5],

            "ultimas_ordenes": OrdenTrabajo.objects.select_related(
                "cliente", "vehiculo"
            ).order_by("-fecha_ingreso")[:5],
        })

        hoy = timezone.localdate()
        inicio = hoy - timedelta(days=6)

        actividad = (
            OrdenTrabajo.objects
            .filter(fecha_ingreso__date__gte=inicio)
            .annotate(dia=TruncDate("fecha_ingreso"))
            .values("dia")
            .annotate(total=Count("id"))
            .order_by("dia")
        )

        conteos = {
            item["dia"]: item["total"]
            for item in actividad
        }

        dias = [
            inicio + timedelta(days=i)
            for i in range(7)
        ]

        contexto["grafico_etiquetas"] = [
            dia.strftime("%d/%m") for dia in dias
        ]

        contexto["grafico_valores"] = [
            conteos.get(dia, 0) for dia in dias
        ]
    
    elif rol == "administrador":
        if request.user.taller_id is None:
            raise PermissionDenied(
                "Este administrador no tiene un taller asignado."
            )

        taller = request.user.taller

        clientes = Cliente.objects.filter(taller=taller)
        vehiculos = Vehiculo.objects.filter(taller=taller)
        ordenes = OrdenTrabajo.objects.filter(taller=taller)

        contexto.update({
            "nombre_taller": taller.nombre,
            "total_clientes": clientes.count(),
            "total_vehiculos": vehiculos.count(),
            "total_ordenes": ordenes.count(),
            "ordenes_activas": ordenes.exclude(
                estado__in=["ENTREGADO", "CANCELADO"]
            ).count(),
            "ordenes_entregadas": ordenes.filter(
                estado="ENTREGADO"
            ).count(),
            "ultimas_ordenes": ordenes.select_related(
                "cliente", "vehiculo"
            ).order_by("-fecha_ingreso")[:5],
        })

    # ==========================================
    # ENTREGAS PROGRAMADAS - DASHBOARD
    # ==========================================

    if rol in ("superadmin", "administrador"):

        hoy = timezone.localdate()
        ahora = timezone.now()
        fin_proximos_dias = hoy + timedelta(days=7)

        if rol == "superadmin":
            ordenes_entrega = OrdenTrabajo.objects.all()
        else:
            ordenes_entrega = OrdenTrabajo.objects.filter(
                taller_id=request.user.taller_id
            )

        # No incluir órdenes entregadas ni canceladas.
        pendientes = ordenes_entrega.exclude(
            estado__in=["ENTREGADO", "CANCELADO"]
        ).filter(
            fecha_entrega__isnull=False
        )

        # Órdenes cuya entrega corresponde a hoy.
        entregas_hoy = pendientes.filter(
            fecha_entrega__date=hoy
        ).count()

        # Órdenes con fecha de entrega ya vencida.
        ordenes_atrasadas = pendientes.filter(
            fecha_entrega__lt=ahora
        ).count()

        # Entregas futuras dentro de los próximos 7 días.
        proximas_entregas = pendientes.filter(
            fecha_entrega__date__gt=hoy,
            fecha_entrega__date__lte=fin_proximos_dias
        ).count()

        # Listado de las próximas entregas pendientes.
        lista_proximas_entregas = (
            pendientes.filter(fecha_entrega__gte=ahora)
            .select_related("cliente", "vehiculo", "taller")
            .order_by("fecha_entrega")[:10]
        )

        contexto.update({
            "entregas_hoy": entregas_hoy,
            "ordenes_atrasadas": ordenes_atrasadas,
            "proximas_entregas": proximas_entregas,
            "lista_proximas_entregas": lista_proximas_entregas,
        })


    return render(
        request,
        "cuentas/dashboard.html",
        contexto
    )



@require_POST
def cerrar_sesion(request):
    logout(request)
    return redirect("login")


@login_required

@login_required
def lista_administradores(request):

    if (
        request.user.rol != Usuario.Rol.SUPERADMIN
        or not request.user.is_superuser
    ):
        raise PermissionDenied

    busqueda = request.GET.get("q", "").strip()
    estado = request.GET.get("estado", "")

    administradores = Usuario.objects.filter(
        rol=Usuario.Rol.ADMIN_TALLER
    ).order_by("username")

    if busqueda:
        administradores = administradores.filter(
            Q(username__icontains=busqueda)
            | Q(first_name__icontains=busqueda)
            | Q(last_name__icontains=busqueda)
            | Q(email__icontains=busqueda)
        )

    if estado == "activos":
        administradores = administradores.filter(
            is_active=True
        )

    elif estado == "inactivos":
        administradores = administradores.filter(
            is_active=False
        )

    paginador = Paginator(administradores, 10)

    pagina = paginador.get_page(
        request.GET.get("page")
    )

    contexto = {
        "administradores": pagina,
        "busqueda": busqueda,
        "estado": estado,

        "total_administradores": Usuario.objects.filter(
            rol=Usuario.Rol.ADMIN_TALLER
        ).count(),

        "administradores_activos": Usuario.objects.filter(
            rol=Usuario.Rol.ADMIN_TALLER,
            is_active=True
        ).count(),

        "administradores_inactivos": Usuario.objects.filter(
            rol=Usuario.Rol.ADMIN_TALLER,
            is_active=False
        ).count(),
    }

    return render(
        request,
        "cuentas/lista_administradores.html",
        contexto
    )

@login_required
def crear_administrador(request):
    if request.user.rol != Usuario.Rol.SUPERADMIN or not request.user.is_superuser:
        raise PermissionDenied
    from .forms import CrearAdministradorForm
    from django.contrib import messages
    form = CrearAdministradorForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        administrador = form.save()
        taller = administrador.taller
        if taller:
            anterior = taller.administrador
            if anterior and anterior.pk != administrador.pk and anterior.taller_id == taller.pk:
                anterior.taller = None
                anterior.save(update_fields=["taller"])
            taller.administrador = administrador
            taller.save(update_fields=["administrador"])
        messages.success(request, "Administrador creado correctamente.")
        return redirect("lista_administradores")
    return render(request, "cuentas/crear_administrador.html", {"form": form})



@login_required
def editar_administrador(request, usuario_id):

    if (
        request.user.rol != Usuario.Rol.SUPERADMIN
        or not request.user.is_superuser
    ):
        raise PermissionDenied

    administrador = get_object_or_404(
        Usuario,
        pk=usuario_id,
        rol=Usuario.Rol.ADMIN_TALLER
    )

    if request.method == "POST":

        formulario = EditarAdministradorForm(
            request.POST,
            instance=administrador
        )

        if formulario.is_valid():

            formulario.save()

            messages.success(
                request,
                "Los datos del administrador se actualizaron correctamente."
            )

            return redirect("lista_administradores")

    else:

        formulario = EditarAdministradorForm(
            instance=administrador
        )

    return render(
        request,
        "cuentas/editar_administrador.html",
        {
            "form": formulario,
            "administrador": administrador,
        }
    )


@login_required
def detalle_administrador(request, usuario_id):

    if (
        request.user.rol != Usuario.Rol.SUPERADMIN
        or not request.user.is_superuser
    ):
        raise PermissionDenied(
            "No tienes permisos para consultar administradores."
        )

    administrador = get_object_or_404(
        Usuario,
        pk=usuario_id,
        rol=Usuario.Rol.ADMIN_TALLER
    )

    talleres = Taller.objects.filter(
        administrador=administrador
    ).order_by("nombre")

    contexto = {
        "administrador": administrador,
        "talleres": talleres,
        "total_talleres": talleres.count(),
    }

    return render(
        request,
        "cuentas/detalle_administrador.html",
        contexto
    )

@login_required
def cambiar_estado_administrador(request, usuario_id):

    if (
        request.user.rol != Usuario.Rol.SUPERADMIN
        or not request.user.is_superuser
    ):
        raise PermissionDenied(
            "No tienes permisos para cambiar el estado."
        )

    administrador = get_object_or_404(
        Usuario,
        pk=usuario_id,
        rol=Usuario.Rol.ADMIN_TALLER
    )

    if request.method == "POST":

        administrador.is_active = not administrador.is_active
        administrador.save(update_fields=["is_active"])

        nuevo_estado = (
            "activada" if administrador.is_active
            else "desactivada"
        )

        messages.success(
            request,
            f"La cuenta de {administrador.username} fue "
            f"{nuevo_estado} correctamente."
        )

        return redirect("lista_administradores")

    return render(
        request,
        "cuentas/confirmar_estado_administrador.html",
        {
            "administrador": administrador,
        }
    )



@login_required
def crear_empleado(request):

    # Solo el administrador del taller puede registrar empleados.
    if request.user.rol != "ADMIN_TALLER":
        messages.error(
            request,
            "No tienes permisos para registrar empleados."
        )
        return redirect("dashboard_rol", rol=request.user.rol)

    taller = request.user.taller

    if taller is None:
        messages.error(
            request,
            "Tu cuenta no tiene un taller asignado."
        )
        return redirect("dashboard_rol", rol=request.user.rol)

    if request.method == "POST":
        form = CrearEmpleadoForm(
            request.POST,
            taller=taller
        )

        if form.is_valid():
            empleado = form.save()

            messages.success(
                request,
                f"El empleado {empleado.username} fue registrado correctamente."
            )

            return redirect("lista_empleados")

    else:
        form = CrearEmpleadoForm(taller=taller)

    return render(
        request,
        "cuentas/crear_empleado.html",
        {
            "form": form,
            "taller": taller,
        }
    )



@login_required
def lista_empleados(request):

    if request.user.rol != "ADMIN_TALLER":
        messages.error(
            request,
            "No tienes permisos para consultar empleados."
        )
        return redirect("dashboard_rol", rol=request.user.rol)

    taller = request.user.taller

    if taller is None:
        messages.error(
            request,
            "Tu cuenta no tiene un taller asignado."
        )
        return redirect("dashboard_rol", rol=request.user.rol)

    empleados = Usuario.objects.filter(
        taller=taller,
        rol__in=[
            Usuario.Rol.MECANICO,
            Usuario.Rol.RECEPCION,
        ]
    ).order_by("first_name", "last_name")

    context = {
        "empleados": empleados,
        "taller": taller,
        "total_empleados": empleados.count(),
        "total_mecanicos": empleados.filter(
            rol=Usuario.Rol.MECANICO
        ).count(),
        "total_recepcionistas": empleados.filter(
            rol=Usuario.Rol.RECEPCION
        ).count(),
    }

    return render(
        request,
        "cuentas/lista_empleados.html",
        context
    )


@login_required
def editar_empleado(request, empleado_id):

    # Solo los administradores de taller pueden editar empleados.
    if request.user.rol != Usuario.Rol.ADMIN_TALLER:
        messages.error(
            request,
            "No tienes permisos para editar empleados."
        )
        return redirect(
            "dashboard_rol",
            rol=request.user.rol
        )

    # Verificar que el administrador tenga un taller.
    if not request.user.taller_id:
        messages.error(
            request,
            "Tu cuenta no tiene un taller asignado."
        )
        return redirect(
            "dashboard_rol",
            rol=request.user.rol
        )

    # Buscar únicamente empleados del taller del administrador.
    empleado = get_object_or_404(
        Usuario,
        pk=empleado_id,
        taller_id=request.user.taller_id,
        rol__in=[
            Usuario.Rol.MECANICO,
            Usuario.Rol.RECEPCION,
        ]
    )

    if request.method == "POST":

        form = EditarEmpleadoForm(
            request.POST,
            instance=empleado
        )

        if form.is_valid():
            form.save()

            messages.success(
                request,
                "Los datos del empleado se actualizaron correctamente."
            )

            return redirect("lista_empleados")

    else:
        form = EditarEmpleadoForm(
            instance=empleado
        )

    return render(
        request,
        "cuentas/editar_empleado.html",
        {
            "form": form,
            "empleado": empleado,
        }
    )


@login_required
@require_POST
def cambiar_estado_empleado(request, empleado_id):

    # Solo el administrador puede gestionar empleados.
    if request.user.rol != Usuario.Rol.ADMIN_TALLER:
        messages.error(
            request,
            "No tienes permisos para modificar empleados."
        )
        return redirect(
            "dashboard_rol",
            rol=request.user.rol
        )

    if not request.user.taller_id:
        messages.error(
            request,
            "Tu cuenta no tiene un taller asignado."
        )
        return redirect(
            "dashboard_rol",
            rol=request.user.rol
        )

    # Solo empleados del mismo taller.
    empleado = get_object_or_404(
        Usuario,
        pk=empleado_id,
        taller_id=request.user.taller_id,
        rol__in=[
            Usuario.Rol.MECANICO,
            Usuario.Rol.RECEPCION,
        ]
    )

    empleado.is_active = not empleado.is_active
    empleado.save(update_fields=["is_active"])

    if empleado.is_active:
        messages.success(
            request,
            f"El empleado {empleado.username} fue activado correctamente."
        )
    else:
        messages.success(
            request,
            f"El empleado {empleado.username} fue desactivado correctamente."
        )

    return redirect("lista_empleados")
