from django.test import TestCase, Client
from django.urls import reverse

from .models import Usuario
from talleres.models import Taller
from appTaller.models import Cliente, Vehiculo, OrdenTrabajo


class IntegracionRolesTest(TestCase):
    def setUp(self):
        self.superadmin = Usuario.objects.create_superuser(
            username="supertest",
            email="supertest@example.local",
            password="TestPass-360!",
            rol=Usuario.Rol.SUPERADMIN,
        )
        self.taller_a = Taller.objects.create(
            nombre="Taller A", rut="11111111-1", direccion="A",
            telefono="111", email="a@example.local", administrador=self.superadmin,
        )
        self.taller_b = Taller.objects.create(
            nombre="Taller B", rut="22222222-2", direccion="B",
            telefono="222", email="b@example.local", administrador=self.superadmin,
        )
        self.admin_a = Usuario.objects.create_user(
            username="admin_a", email="admin_a@example.local",
            password="TestPass-360!", rol=Usuario.Rol.ADMIN_TALLER,
            taller=self.taller_a,
        )

    def test_usuario_sin_sesion_es_enviado_al_login(self):
        response = self.client.get(reverse("lista_ordenes"))
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])

    def test_administrador_solo_ve_clientes_de_su_taller(self):
        Cliente.objects.create(
            taller=self.taller_a, rut="33333333-3", nombre="Cliente A", telefono="111"
        )
        Cliente.objects.create(
            taller=self.taller_b, rut="44444444-4", nombre="Cliente B", telefono="222"
        )
        self.client.login(username="admin_a", password="TestPass-360!")
        response = self.client.get(reverse("lista_clientes"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Cliente A")
        self.assertNotContains(response, "Cliente B")

    def test_mecanico_solo_ve_ordenes_asignadas_y_no_puede_crear_recepciones(self):
        mecanico = Usuario.objects.create_user(
            username="mecanico_a", email="mecanico_a@example.local",
            password="TestPass-360!", rol=Usuario.Rol.MECANICO,
            taller=self.taller_a,
        )
        cliente = Cliente.objects.create(
            taller=self.taller_a, rut="55555555-5", nombre="Cliente mecánico", telefono="555"
        )
        vehiculo_asignado = Vehiculo.objects.create(
            taller=self.taller_a, cliente=cliente, patente="AAA111",
            marca="Marca", modelo="Asignado", anio=2020,
        )
        vehiculo_no_asignado = Vehiculo.objects.create(
            taller=self.taller_a, cliente=cliente, patente="BBB222",
            marca="Marca", modelo="No asignado", anio=2021,
        )
        OrdenTrabajo.objects.create(
            taller=self.taller_a, cliente=cliente, vehiculo=vehiculo_asignado,
            kilometraje_ingreso=10, motivo_ingreso="Trabajo asignado",
            mecanico_asignado=mecanico,
        )
        OrdenTrabajo.objects.create(
            taller=self.taller_a, cliente=cliente, vehiculo=vehiculo_no_asignado,
            kilometraje_ingreso=20, motivo_ingreso="Trabajo no asignado",
        )
        self.client.login(username="mecanico_a", password="TestPass-360!")
        response = self.client.get(reverse("lista_ordenes"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "AAA111")
        self.assertNotContains(response, "BBB222")
        self.assertEqual(self.client.get(reverse("nueva_recepcion")).status_code, 403)

    def test_superadministrador_puede_gestionar_talleres(self):
        self.client.login(username="supertest", password="TestPass-360!")
        response = self.client.get(reverse("lista_talleres"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Taller A")
        self.assertContains(response, "Taller B")
    def test_orden_nueva_se_crea_solo_desde_presupuesto_aprobado(self):
        self.client.login(username="admin_a", password="TestPass-360!")
        response = self.client.get(reverse("nueva_orden"))
        self.assertRedirects(response, reverse("nueva_recepcion"), fetch_redirect_response=False)

