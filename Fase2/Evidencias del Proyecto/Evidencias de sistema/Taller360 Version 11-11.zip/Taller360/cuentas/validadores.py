
import re
from django.core.exceptions import ValidationError


def normalizar_rut(rut):
    """
    Convierte el RUT a un formato estándar.
    Ejemplo: 12.345.678-k -> 12345678-K
    """
    rut = str(rut).strip().upper()
    rut = rut.replace(".", "").replace("-", "")

    if not re.fullmatch(r"[0-9]{2,8}[0-9K]", rut):
        raise ValidationError(
            "El RUT debe contener entre 2 y 8 dígitos "
            "más su dígito verificador."
        )

    return f"{int(rut[:-1])}-{rut[-1]}"


def validar_rut(rut):
    """
    Valida el dígito verificador mediante módulo 11.
    """
    rut_normalizado = normalizar_rut(rut)

    numero, dv = rut_normalizado.split("-")

    suma = 0
    multiplicador = 2

    for digito in reversed(numero):
        suma += int(digito) * multiplicador
        multiplicador += 1

        if multiplicador > 7:
            multiplicador = 2

    resto = 11 - (suma % 11)

    if resto == 11:
        dv_calculado = "0"
    elif resto == 10:
        dv_calculado = "K"
    else:
        dv_calculado = str(resto)

    if dv != dv_calculado:
        raise ValidationError(
            "El RUT ingresado no es válido."
        )

    return rut_normalizado
