
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError

from .models import Usuario
from talleres.models import Taller


class CrearAdministradorForm(UserCreationForm):
    class Meta:
        model = Usuario
        fields = [
            "username",
            "first_name",
            "last_name",
            "rut",
            "email",
            "telefono",
            "taller",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["taller"].queryset = Taller.objects.filter(activo=True)
        self.fields["taller"].required = True
        self.fields["taller"].label = "Taller asignado"

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()

        if Usuario.objects.filter(email__iexact=email).exists():
            raise ValidationError("Este correo ya está registrado.")

        return email

    def clean_rut(self):
        rut = self.cleaned_data["rut"].strip().upper()

        if Usuario.objects.filter(rut__iexact=rut).exists():
            raise ValidationError("Este RUT ya está registrado.")

        return rut

    def save(self, commit=True):
        usuario = super().save(commit=False)
        usuario.rol = Usuario.Rol.ADMIN_TALLER
        usuario.is_staff = False
        usuario.is_superuser = False

        if commit:
            usuario.save()

        return usuario



class EditarAdministradorForm(forms.ModelForm):

    class Meta:
        model = Usuario

        fields = [
            "username",
            "first_name",
            "last_name",
            "rut",
            "email",
            "telefono",
        ]

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()

        if Usuario.objects.filter(
            email__iexact=email
        ).exclude(pk=self.instance.pk).exists():
            raise ValidationError(
                "Este correo ya está registrado."
            )

        return email

    def clean_rut(self):
        rut = self.cleaned_data["rut"].strip().upper()

        if Usuario.objects.filter(
            rut__iexact=rut
        ).exclude(pk=self.instance.pk).exists():
            raise ValidationError(
                "Este RUT ya está registrado."
            )

        return rut


class CrearEmpleadoForm(UserCreationForm):

    rol = forms.ChoiceField(
        choices=[
            (Usuario.Rol.MECANICO, "Mecánico"),
            (Usuario.Rol.RECEPCION, "Recepcionista"),
        ],
        label="Cargo del empleado"
    )

    class Meta:
        model = Usuario
        fields = [
            "username",
            "first_name",
            "last_name",
            "rut",
            "email",
            "telefono",
            "rol",
        ]

        labels = {
            "username": "Nombre de usuario",
            "first_name": "Nombres",
            "last_name": "Apellidos",
            "rut": "RUT",
            "email": "Correo electrónico",
            "telefono": "Teléfono",
        }

    def __init__(self, *args, taller=None, **kwargs):
        super().__init__(*args, **kwargs)

        if taller is None:
            raise ValueError(
                "Debes indicar el taller del empleado."
            )

        self.taller = taller

        for campo in self.fields.values():
            campo.widget.attrs["class"] = "form-control"

        self.fields["first_name"].required = True
        self.fields["last_name"].required = True
        self.fields["rut"].required = True
        self.fields["email"].required = True

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()

        if Usuario.objects.filter(
            email__iexact=email
        ).exists():
            raise ValidationError(
                "Este correo electrónico ya está registrado."
            )

        return email

    def clean_rut(self):
        rut = self.cleaned_data["rut"].strip().upper()

        if Usuario.objects.filter(
            rut__iexact=rut
        ).exists():
            raise ValidationError(
                "Este RUT ya está registrado."
            )

        return rut

    def save(self, commit=True):
        empleado = super().save(commit=False)

        empleado.rol = self.cleaned_data["rol"]
        empleado.taller = self.taller
        empleado.is_active = True
        empleado.is_staff = False
        empleado.is_superuser = False

        if commit:
            empleado.save()

        return empleado



class EditarEmpleadoForm(forms.ModelForm):

    rol = forms.ChoiceField(
        choices=[
            (Usuario.Rol.MECANICO, "Mecánico"),
            (Usuario.Rol.RECEPCION, "Recepcionista"),
        ],
        label="Cargo del empleado"
    )

    class Meta:
        model = Usuario

        fields = [
            "first_name",
            "last_name",
            "rut",
            "email",
            "telefono",
            "rol",
        ]

        labels = {
            "first_name": "Nombres",
            "last_name": "Apellidos",
            "rut": "RUT",
            "email": "Correo electrónico",
            "telefono": "Teléfono",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for campo in self.fields.values():
            campo.widget.attrs["class"] = "form-control"

        self.fields["first_name"].required = True
        self.fields["last_name"].required = True
        self.fields["rut"].required = True
        self.fields["email"].required = True

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()

        existe = Usuario.objects.filter(
            email__iexact=email
        ).exclude(
            pk=self.instance.pk
        ).exists()

        if existe:
            raise forms.ValidationError(
                "Este correo electrónico ya está registrado."
            )

        return email

    def clean_rut(self):
        rut = self.cleaned_data["rut"].strip().upper()

        existe = Usuario.objects.filter(
            rut__iexact=rut
        ).exclude(
            pk=self.instance.pk
        ).exists()

        if existe:
            raise forms.ValidationError(
                "Este RUT ya está registrado."
            )

        return rut
