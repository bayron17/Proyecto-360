
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import Usuario


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    list_display = (
        "username",
        "first_name",
        "last_name",
        "rut",
        "email",
        "rol",
        "is_active",
    )

    list_filter = (
        "rol",
        "is_active",
        "is_staff",
    )

    search_fields = (
        "username",
        "first_name",
        "last_name",
        "rut",
        "email",
    )

    fieldsets = UserAdmin.fieldsets + (
        (
            "Información Taller360",
            {
                "fields": (
                    "rut",
                    "telefono",
                    "rol",
                )
            },
        ),
    )

    add_fieldsets = UserAdmin.add_fieldsets + (
        (
            "Información Taller360",
            {
                "fields": (
                    "email",
                    "rut",
                    "telefono",
                    "rol",
                )
            },
        ),
    )
