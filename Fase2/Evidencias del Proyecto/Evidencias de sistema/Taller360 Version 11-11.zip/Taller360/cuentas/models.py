
from django.contrib.auth.models import AbstractUser
from django.db import models


class Usuario(AbstractUser):
    class Rol(models.TextChoices):
        SUPERADMIN = "SUPERADMIN", "Superadministrador"
        ADMIN_TALLER = "ADMIN_TALLER", "Administrador de taller"
        RECEPCION = "RECEPCION", "Recepcionista"
        MECANICO = "MECANICO", "Mecánico"
        CLIENTE = "CLIENTE", "Cliente"

    rut = models.CharField(
        max_length=12,
        unique=True,
        null=True,
        blank=True
    )

    telefono = models.CharField(
        max_length=20,
        blank=True
    )

    rol = models.CharField(
        max_length=20,
        choices=Rol.choices,
        default=Rol.CLIENTE
    )

    email = models.EmailField(unique=True)

    taller = models.ForeignKey(
        "talleres.Taller",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="usuarios"
    )

    def __str__(self):
        return f"{self.get_full_name()} ({self.username})"
