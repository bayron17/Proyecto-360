
from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied

from .models import Usuario


def es_superadmin(usuario):
    return (
        usuario.is_authenticated
        and usuario.is_active
        and usuario.rol == Usuario.Rol.SUPERADMIN
        and usuario.is_superuser
    )


def tiene_rol(usuario, *roles):
    if not usuario.is_authenticated or not usuario.is_active:
        return False

    if usuario.rol not in roles:
        return False

    if usuario.rol == Usuario.Rol.SUPERADMIN:
        return usuario.is_superuser

    return True


def requiere_roles(*roles):
    def decorador(vista):
        @login_required
        @wraps(vista)
        def funcion_protegida(request, *args, **kwargs):
            if not tiene_rol(request.user, *roles):
                raise PermissionDenied(
                    "No tienes permisos para acceder a esta sección."
                )

            return vista(request, *args, **kwargs)

        return funcion_protegida

    return decorador


def obtener_taller_usuario(usuario):
    if not usuario.is_authenticated or not usuario.is_active:
        raise PermissionDenied(
            "Debes iniciar sesión con una cuenta activa."
        )

    if es_superadmin(usuario):
        return None

    if usuario.rol not in (
        Usuario.Rol.ADMIN_TALLER,
        Usuario.Rol.RECEPCION,
        Usuario.Rol.MECANICO,
    ):
        raise PermissionDenied(
            "Este usuario no tiene acceso administrativo a talleres."
        )

    if usuario.taller_id is None:
        raise PermissionDenied(
            "Tu cuenta no tiene un taller asignado."
        )

    return usuario.taller


def filtrar_por_taller(queryset, usuario):
    if es_superadmin(usuario):
        return queryset

    taller = obtener_taller_usuario(usuario)

    return queryset.filter(taller=taller)
